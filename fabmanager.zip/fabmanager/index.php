<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>FABMANAGER - Accueil</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f6f6f7;
      color: #333;
      margin: 0;
      padding: 0;
    }

    /* Navbar */
    .navbar {
      background-color: #3ed8b4;
    }

    .navbar-brand {
      font-weight: bold;
    }

    .navbar-nav .nav-link {
      color: #fff;
      font-weight: bold;
    }

    /* Main Banner */
    .banner {
      background: url('https://static.wixstatic.com/media/0784b1_9943cc4804b2414b9ddd1dd1ee838454~mv2.jpg/v1/fill/w_718,h_462,al_c,q_80,enc_auto/greenBG.jpg') no-repeat center center;
      background-size: cover;
      text-align: center;
      padding: 100px 0;
    }

    .banner h1 {
      color: #fff;
      font-size: 3em;
      font-weight: bold;
      margin-bottom: 20px;
    }

    .banner p {
      color: #fff;
      font-size: 1.2em;
      margin-bottom: 30px;
    }

    /* Cards Section */
    .card-title {
      font-weight: bold;
    }

    /* Footer */
    .footer {
      background-color: #333;
      color: #fff;
      text-align: center;
      padding: 20px 0;
    }
  </style>
</head>
<body>
  <!-- Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">FABMANAGER</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
          <!-- <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#">Accueil</a>
          </li> -->
          <!-- <li class="nav-item">
            <a class="nav-link" href="#">Nos fonctionnalités</a>
          </li> -->
          <li class="nav-item">
            <a class="btn btn-primary" href="accueil.php">Connexion</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Main Banner -->
  <section class="banner">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h1>Fabmanager, accès fluide</h1>
          <p>Easy find, trouver aisément le matériel</p>
          <a href="accueil.php" class="btn btn-lg btn-primary me-2">Connectez-vous</a>
          <a href="fonctionalités.php" class="btn btn-lg btn-outline-light">Fonctionnalités</a>
        </div>
      </div>
    </div>
  </section>

  <!-- Cards Section -->
  <section class="container py-5">
    <div class="row g-4">
      <!-- First Card -->
      <div class="col-md-6">
        <div class="card h-100">
          <img src="https://www.ipmarketplace.ma/storage/listing-uploads/logo/2023/05/ECC-Logos-Centrale-Fond-blanc-6.png" class="card-img-top" alt="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-6bLjVtWdN8RjoLjniBemXC7CyDSQOVcolDRfold3KQ&s">
          <div class="card-body">
            <h5 class="card-title">École Centrale Casablanca</h5>
            <p class="card-text">La formation centralienne se distingue par son haut niveau scientifique et son intégration d'une expérience internationale enrichissante. Les cours rigoureux couvrent diverses disciplines techniques et scientifiques, enseignées par des professeurs renommés. Les étudiants participent à des échanges universitaires, des stages à l'étranger et des projets internationaux, améliorant leurs compétences linguistiques et leur compréhension interculturelle. Cette approche globale prépare les ingénieurs à relever les défis complexes et à s'adapter à des environnements multiculturels, facilitant ainsi leur insertion sur le marché du travail international.</p>
          </div>
          <div class="card-footer">
            <a href="https://centrale-casablanca.ma/" class="btn btn-sm btn-primary">Découvrez plus sur le site officiel de l'École</a>
          </div>
        </div>
      </div>
      <!-- Second Card with Carousel -->
      <div class="col-md-6">
        <div class="card h-100">
          <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSF8FKeHcrmcB0JZyG3jSh1UlxHVombEj0iqIDbC1tdNg&s" class="d-block w-100" alt="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSBeW4LceO5iL1VYJUHfaPmK7wdeTpLEONcjDGRQQfbKA&s">
              </div>
              <div class="carousel-item">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSoCuaDi3WtpF-P6-J5e4PTyLJwsgpIY1Rc4BmNBiK8B5UzUlLsJTOJBmTGv3QPrAvtnpE&usqp=CAU" class="d-block w-100" alt="https://aujourdhui.ma/wp-content/uploads/2022/04/LEcole-Centrale-Casablanca.png">
              </div>
              <div class="carousel-item active">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSBeW4LceO5iL1VYJUHfaPmK7wdeTpLEONcjDGRQQfbKA&s" class="d-block w-100" alt="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSBeW4LceO5iL1VYJUHfaPmK7wdeTpLEONcjDGRQQfbKA&s">
              </div>
              <div class="carousel-item active">
                <img src="https://media.licdn.com/dms/image/C4D1BAQH0zHXuTQoOng/company-background_10000/0/1638356078312/ecc_club_robotique_et_intelligence_artificielle_cover?e=2147483647&v=beta&t=h_NbjLHymp0DUdxWN5ez1IItVn1_r1VDQ9FuX4emA8k" class="d-block w-100" alt="https://media.licdn.com/dms/image/C4D1BAQH0zHXuTQoOng/company-background_10000/0/1638356078312/ecc_club_robotique_et_intelligence_artificielle_cover?e=2147483647&v=beta&t=h_NbjLHymp0DUdxWN5ez1IItVn1_r1VDQ9FuX4emA8k">
              </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Next</span>
            </button>
          </div>
          <div class="card-body">
            <h5 class="card-title">Fablab</h5>
            <p class="card-text">Le FABLAB de l'École Centrale Casablanca est un espace de fabrication numérique où les étudiants et la communauté peuvent concevoir et réaliser des projets innovants grâce à des outils technologiques avancés.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="footer">
    <div class="container text-center">
      <span>Tout droit réservé sur Fabmanager.</span>
    </div>
  </footer>

  <!-- Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
