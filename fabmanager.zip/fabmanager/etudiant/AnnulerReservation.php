<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmation de réservation</title>
    <style>
        /* Styles généraux */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        nav ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fff;
        }

        main {
            padding: 20px;
        }

        .confirmation {
            background-color: #63b2b4;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 30px;
            text-align: center;
        }

        .confirmation h2 {
            color: #333;
        }

        .confirmation p {
            color: #666;
            margin-bottom: 20px;
        }

        .actions {
            list-style-type: none;
            padding: 0;
        }

        .actions li {
            margin-top: 10px;
        }

        .actions li a {
            display: inline-block;
            padding: 10px 20px;
            background-color: #333;
            color: #4fc2d1;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .actions li a:hover {
            background-color: #555;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Lien vers Font Awesome -->
</head>
<body>
    <header>
        <h1>Confirmation de réservation</h1>
        <nav>
            <ul>
                <?php
                    $pageAccueil = "page_accueil.php";
                    $pageProfil = "page_mod_profil.php";
                    $pageReservation = "reservermatériel.php";
                    $pageAutre = "autre_page.php";
                ?>
                <li><a href="<?php echo $pageAccueil; ?>"><i class="fas fa-home"></i> Accueil</a></li>
                <li><a href="<?php echo $pageProfil; ?>"><i class="fas fa-user-cog"></i> Modifier le profil</a></li>
                <li><a href="<?php echo $pageReservation; ?>"><i class="fas fa-calendar-plus"></i> Réserver du matériel</a></li>
                <li><a href="<?php echo $_SERVER['HTTP_REFERER']; ?>"><i class="fas fa-external-link-alt"></i> Retour à la page précédente</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section class="confirmation">
            <h2>Votre réservation a été enregistrée avec succès!</h2>
            <form action="modifier_reservation.php" method="post">
            <p>Merci d'avoir réservé du matériel. Vous pouvez maintenant :</p>
            <ul class="actions">
                <li><a href="modifier_reservation.php"><i class="fas fa-edit"></i> Modifier votre réservation</a></li>
                <li><a href="annulation_reservation.php"><i class="fas fa-trash-alt"></i> Annuler votre réservation</a></li>
            </ul>
        </section>
    </main>
    <footer>
        <div class="contact-info">
            <h3>Comment nous contacter</h3>
            <p>Pour plus d'informations sur nos services, nos formations dans le fablab, n'hésitez pas à nous contacter :</p>
            <ul>
                <li>Téléphone : +212 6 46 56 97 88</li>
                <li>Email : contact@fablab.com</li>
                <li>Adresse : Ecole centrale casablanca, BOUSKOURA, MAROC</li>
            </ul>
        </div>
    </footer>
    
</body>
</html>
