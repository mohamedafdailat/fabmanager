<?php
session_start();

$db_host = 'localhost';
$db_name = 'fabmanager';
$db_user = 'root';
$db_pass = '';

try {
    $conn = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Vérifie si le panier existe dans la session, sinon le crée
    if (!isset($_SESSION['panier'])) {
        $_SESSION['panier'] = [];
    }

    // Ajoute les matériels au panier lorsque le formulaire est soumis
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
        if (isset($_POST['materials']) && isset($_POST['quantities']) && isset($_POST['EmplacementFablab']) && isset($_POST['Disponibilite'])) {
            $materials = $_POST['materials'];
            $quantities = $_POST['quantities'];
            $EmplacementFablabs = $_POST['EmplacementFablab'];
            $Disponibilites = $_POST['Disponibilite'];

            for ($i = 0; $i < count($materials); $i++) {
                $material = $materials[$i];
                $quantity = $quantities[$i];
                $EmplacementFablab = $EmplacementFablabs[$i];
                $Disponibilite = $Disponibilites[$i];

                $_SESSION['panier'][] = [
                    'NomMatériel' => $material,
                    'Quantité' => $quantity,
                    'EmplacementFablab' => $EmplacementFablab,
                    'Disponibilite' => $Disponibilite
                ];
            }
        }

        // Redirige vers la page panier.php
        header('Location: panier2.php');
        exit;
    } else {
        // Redirige vers la page précédente si le formulaire n'est pas soumis
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        exit;
    }
} catch (PDOException $e) {
    echo "Erreur de connexion : " . $e->getMessage();
}
?>
