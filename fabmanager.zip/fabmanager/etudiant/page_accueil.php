<?php
session_start();

// Suppose $reservationDate est la date de la réservation (remplacez cette variable par la valeur appropriée)
$reservationDate = '2024-06-20'; // Exemple de date de réservation

// Compare la date de la réservation avec la date actuelle pour déterminer si elle est récente
if (strtotime($reservationDate) >= strtotime('-7 days')) { // Si la réservation est dans les 7 derniers jours
    $_SESSION['notification_message'] = "Nouvelle réservation ajoutée.";
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FABMANAGER - Tableau de bord</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f6f6f7;
            color: #2ec086;
            margin: 0;
            padding: 0;
        }
        #notification {
            display: none;
            background-color: #4CAF50;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            top: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 300px;
            z-index: 1000;
        }

        header {
            display: flex;
            align-items: center;
            background-color: #3ed8b4;
            color: #fbfbfb;
            padding: 20px;
        }

        #company-logo {
            height: 80px;
            width: auto;
            margin-right: 10px;
        }

        h1 {
            margin: 0;
            font-size: 1.5em;
        }

        nav {
            margin-left: auto;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fbfbfb;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            transition: color 0.3s ease;
        }

        nav ul li a:hover {
            background-color: #36bfb0;
        }

        .notification-icon:hover {
            background-color: #36bfb0;
        }

        main {
            display: flex;
        }

        .sidebar {
            background-color: #3ed8b4;
            color: #fff;
            padding: 20px;
            margin: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            width: 300px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .sidebar h2 {
            margin-bottom: 20px;
            font-size: 1.5em;
            color: #fff;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
            text-align: center;
        }

        .sidebar li {
            margin-bottom: 10px;
        }

        .sidebar li a {
            text-decoration: none;
            color: #fff;
            font-size: 1.2em;
            transition: color 0.3s ease;
        }

        .sidebar li a:hover {
            color: #36bfb0;
        }

        .content {
            display: flex;
            flex-direction: column;
            width: calc(100% - 340px);
            margin: 20px;
        }

        section {
            background-color: #fff;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            flex: 1;
        }

        #notification-container {
            width: 90%;
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .reservation-details {
            margin-bottom: 20px;
        }

        .reservation-details h2 {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .reservation-details ul {
            list-style-type: none;
            padding: 0;
        }

        .reservation-details li {
            margin-bottom: 10px;
        }

        .notification-icon {
            font-size: 20px;
            cursor: pointer;
            color: #ffff;
            text-align: center;
            margin-top: 20px;
        }

        .popup-notification {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ddd;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            z-index: 1000;
        }

        .popup-notification.success {
            border-color: #4CAF50;
            color: #4CAF50;
        }

        .popup-notification.error {
            border-color: #f44336;
            color: #f44336;
        }

        .popup-notification button {
            margin-top: 10px;
            padding: 5px 10px;
            border: none;
            background-color: #007bff;
            color: #fff;
            border-radius: 5px;
            cursor: pointer;
        }

        .no-reservation, .no-user {
            text-align: center;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .submenu {
            display: none;
            list-style-type: none;
            padding: 0;
            margin: 0;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
        }

        .submenu li {
            display: block;
        }

        .submenu li a {
            display: block;
            padding: 10px;
            text-decoration: none;
            color: #333;
        }

        .submenu li a:hover {
            background-color: #f1f1f1;
        }
        header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #3ed8b4;
    padding: 20px;
    color: #fbfbfb;
}

.header-content {
    display: flex;
    align-items: center;
}

#company-logo {
    height: 80px;
    margin-right: 20px;
}

h1 {
    margin: 0;
    font-size: 1.5em;
}

nav ul {
    list-style-type: none;
    display: flex;
    margin: 0;
    padding: 0;
}

nav ul li {
    margin-right: 20px;
}

nav ul li a {
    text-decoration: none;
    color: #fbfbfb;
    font-weight: bold;
    padding: 5px 10px;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

nav ul li a:hover {
    background-color: #36bfb0;
}

.dropdown {
    position: relative;
}

.submenu {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    border: 1px solid #ddd;
    list-style-type: none;
    padding: 10px;
    margin: 0;
    top: 100%;
    left: 0;
}

.submenu li {
    margin-bottom: 10px;
}

.submenu li a {
    color: #333;
    text-decoration: none;
    padding: 10px;
    display: block;
}

.submenu li a:hover {
    background-color: #f1f1f1;
}

.dropdown:hover .submenu {
    display: block;
}
h1 {
         margin: 20; /* Supprimer la marge pour éviter l'espace supplémentaire */
         font-size: 1.5em; /* Taille du titre augmentée */
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var parentLink = document.querySelector('a[href="reservermateriel.php"]');
            var submenu = document.querySelector('.submenu');

            parentLink.addEventListener('click', function(event) {
                event.preventDefault();
                submenu.style.display = (submenu.style.display === 'block') ? 'none' : 'block';
            });
        });

        function showNotificationDetails() {
            var popup = document.getElementById('popup-notification');
            popup.style.display = 'block';
        }

        function closeNotification() {
            var popup = document.getElementById('popup-notification');
            popup.style.display = 'none';
        }
    </script>
</head>
<body>
<header>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <div class="header-content">
        <img src="logo.png" alt="Logo de l'entreprise" id="company-logo">
        <h1>Tableau de bord - Etudiant</h1>
    </div>
    <nav>
    <ul>
    <li class="dropdown">
        <a href="reservermateriel.php"><i class="fas fa-calendar-alt"></i> Réserver le matériel</a>
        <ul class="submenu">
            <li><a href="ManipulationMatériel.php"><i class="fas fa-edit"></i> Procéder à la réservation</a></li>
            <li><a href="reservermatériel.php"><i class="fas fa-plus-circle"></i> Réserver autrement</a></li>
        </ul>
    </li>
    <li><a href="manipulation.php"><i class="fas fa-tasks"></i> Consulter les manipulations</a></li>
    <li><a href="autre_page.php"><i class="fas fa-info-circle"></i> À propos de nous</a></li>
    <li><a href="Mod.php"><i class="fas fa-user"></i> Profile</a></li>
    <li><a href="login.php"><i class="fas fa-sign-out-alt"></i> Déconnexion</a></li>
</ul>
    </nav>
</header>
    <main>
        <div class="sidebar">
            <h2>Actions Rapides</h2>
            <ul>
                <li><a href="page_mod_profil.php"><i class="fas fa-user-plus"></i> Consulter et modifier compte </a></li>
                <br><br>
                <li><a href="reservermatériel.php"><i class="fas fa-laptop"></i> Voir matériel disponible </a></li>
                <br><br>
                <li><a href="emplois_du_temps.php"><i class="fas fa-clock"></i> Voir crénaux disponibles </a></li>
                <br><br>
                <li><a href="mes_projets_lies.php"><i class="fas fa-link"></i> Mes projets liés </a></li>
                <br>
                <?php
                if (isset($_SESSION['user_id'])) {
                    $user_id = $_SESSION['user_id'];
                    $conn = new mysqli('localhost', 'root', '', 'fabmanager');

                    if ($conn->connect_error) {
                        die("La connexion a échoué: " . $conn->connect_error);
                    }

                    $sql_count = "SELECT COUNT(*) as count FROM réservation WHERE utilisateur_id = $user_id AND (StatutReservation = 'Confirmé' OR StatutReservation = 'Refusé')";
                    $result_count = $conn->query($sql_count);
                    $row_count = $result_count->fetch_assoc();
                    $notification_count = $row_count['count'];

                    $sql_reservation = "SELECT ID, NomResponsable, Typedereservation, DateReservation, Heure, StatutReservation FROM réservation WHERE utilisateur_id = $user_id AND (StatutReservation = 'Confirmé' OR StatutReservation = 'Refusé') ORDER BY DateReservation DESC, Heure DESC";
                    $result_reservation = $conn->query($sql_reservation);
                    $reservations = [];

                    while($row_reservation = $result_reservation->fetch_assoc()) {
                        $reservations[] = $row_reservation;
                    }

                    if ($notification_count > 0) {
                        echo "<div class='notification-icon' onclick='showNotificationDetails()'>Notification";
                        echo "<i class='fa-solid fa-bell'></i>";
                        echo "<span class='notification-count'>$notification_count</span>";
                        echo "</div>";
                    }

                    $conn->close();
                }
                ?>
            </ul>
        </div>
        <div class="content">
            <section>
                <h2>Informations générales sur le FABLAB</h2>
                <p>Le FABLAB ECC représente un projet de plateforme de production ainsi que de prototypage innovant et collaboratif à l’usage d’une communauté de créateurs écoresponsables dans le but de partager des connaissances, un espace et des outils.</p>
            </section>
            <section>
                <h2>FABLAB de l'école centrale casablanca <i class=""></i></h2>
                <img src="fablab.png" alt="FABLAB" style="max-width: 200%; height: auto;">
            </section>
            <?php if (!empty($reservations)): ?>
                <div id="popup-notification" class="popup-notification">
                    <h2>Détails des Réservations</h2>
                    <?php foreach ($reservations as $reservation): ?>
                        <div class="reservation">
                            <p><strong>ID:</strong> <?php echo $reservation['ID']; ?></p>
                            <p><strong>Nom du Responsable:</strong> <?php echo $reservation['NomResponsable']; ?></p>
                            <p><strong>Type de réservation:</strong> <?php echo $reservation['Typedereservation']; ?></p>
                            <p><strong>Date de réservation:</strong> <?php echo $reservation['DateReservation']; ?></p>
                            <p><strong>Heure:</strong> <?php echo $reservation['Heure']; ?></p>
                            <p><strong>Statut:</strong> <?php echo $reservation['StatutReservation']; ?></p>
                        </div>
                        <hr>
                    <?php endforeach; ?>
                    <button onclick="closeNotification()">Fermer</button>
                </div>
            <?php endif; ?>
            <script>
                function showNotificationDetails() {
                    var popup = document.getElementById('popup-notification');
                    popup.style.display = 'block';
                }

                function closeNotification() {
                    var popup = document.getElementById('popup-notification');
                    popup.style.display = 'none';
                }
            </script>
            <section>
                <h2> Emploi du temps des étudiants actuel <i class="far fa-calendar-alt"></i></h2>
                <img src="emploi.png" alt="Emploi du temps des étudiants" style="max-width: 150%; height: auto;">
                <p>Cet emploi pourrait etre modifier par le service planification, pour plus d'informations contacter la scolarité.</p>
            </section>
            <section>
                <h2>Liens utiles <i class="fas fa-link"></i></h2>
                <ul>
                    <li><a href="page_mod_profil.php">Modifier le profil <i class="fas fa-user-cog"></i></a></li>
                    <li><a href="reservermatériel.php">Réserver du matériel <i class="fas fa-calendar-plus"></i></a></li>
                    <li><a href="autre_page.php">Autre page <i class="fas fa-external-link-alt"></i></a></li>
                </ul>
            </section>
        </div>
    </main>
    <footer>
        <!-- Pied de page -->
    </footer>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var dropdown = document.querySelector('.dropdown');

        dropdown.addEventListener('mouseenter', function() {
            var submenu = this.querySelector('.submenu');
            submenu.style.display = 'block';
        });

        dropdown.addEventListener('mouseleave', function() {
            var submenu = this.querySelector('.submenu');
            submenu.style.display = 'none';
        });
    });
</script>

</body>
</html>
