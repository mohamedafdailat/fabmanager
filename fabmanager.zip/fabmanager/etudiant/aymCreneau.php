<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "fabmanager";
    
    $conn = new mysqli($servername, $username, $password, $database);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    // Récupération des informations de l'utilisateur
    // $user_id = $_SESSION['user_id'];
    $sql = "SELECT * FROM utilisateur WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $username = $user['username'];
        $id = $user['id'];
    } else {
        echo "Utilisateur non trouvé.";
    }
    $stmt->close();
    $conn->close();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manipulations et Matériels</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f6f6f7;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            height: 100vh;
        }

        header {
            background: linear-gradient(to right, #3ed8b4, #36bfb0);
            color: #fff;
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: center;
            display: flex;
            justify-content: center;
        }

        nav ul li {
            margin: 0 15px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 5px;
            background-color: #3ed8b4;
            transition: background-color 0.3s ease;
        }

        nav ul li a:hover {
            background-color: #36bfb0;
        }

        .container {
            width: 100%;
            max-width: 900px;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin: 20px auto;
        }

        h1 {
            text-align: center;
            font-size: 1.8em;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f8f9fa;
            color: #343a40;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #e9ecef;
        }

        .no-data {
            text-align: center;
            font-size: 18px;
            color: #888;
            margin-top: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
        }

        .form-group input[type="text"],
        .form-group input[type="date"],
        .form-group input[type="time"] {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
            outline: none;
            transition: border-color 0.3s ease;
        }

        .form-group input[type="text"]:focus,
        .form-group input[type="date"]:focus,
        .form-group input[type="time"]:focus {
            border-color: #5cb85c;
        }

        .form-group input[type="submit"] {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #5cb85c;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .form-group input[type="submit"]:hover {
            background-color: #4cae4c;
        }

        .radio-inline {
            margin-right: 10px;
        }
    </style>
</head>
<body>
<header>
    <h1>Tableau de bord - Étudiant</h1>
    <nav>
        <ul>
            <li><a href="page_accueil.php">Accueil</a></li>
            <li><a href="Reservation.php">Réserver un créneau</a></li>
            <li><a href="manipulation.php">Consulter les manipulations</a></li>
            <li><a href="login.php">Déconnexion</a></li>
        </ul>
    </nav>
</header>

<div class="container">
    <div id="result">
        <?php
        $db_host = 'localhost';
        $db_name = 'fabmanager';
        $db_user = 'root';
        $db_pass = '';

        try {
            $conn = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $manipulation_id = $_POST['manipulation_id'];
                $matériels = $_POST['matériels'];
                $quantité = $_POST['quantité'];

                echo "<h2>Détails du créneau réservé</h2>";
                echo "<table>";
                echo "<thead><tr><th>Matériels</th><th>Quantité</th></tr></thead>";
                echo "<tbody>";
                echo "<tr>";
                echo "<td>$matériels</td>";
                echo "<td>$quantité</td>";
                echo "</tr>";
                echo "</tbody>";
                echo "</table>";
            }
        } catch (PDOException $e) {
            echo "Erreur de connexion : " . $e->getMessage();
        }
        $conn = null;
        ?>

        <?php
        if (isset($success_message)) {
            echo "<div class='message'>$success_message</div>";
        }
        ?>

        <form action="Reservation1.php" method="post">
            <input type="hidden" id="UserID" name="UserID" value="<?php echo htmlspecialchars($id); ?>">

            <div class="form-group">
                <label for="NomResponsable">Nom complet du responsable</label>
                <input type="text" id="NomResponsable" name="NomResponsable" value="<?php echo htmlspecialchars($username); ?>" required>
            </div>
            <div class="form-group">
                <label for="Typedereservation">Type de réservation</label>
                <div>
                    <label for="individuel" class="radio-inline">
                        <input type="radio" name="Typedereservation" id="individuel" value="Individuel" required>Individuel
                    </label>
                    <label for="En groupe" class="radio-inline">
                        <input type="radio" name="Typedereservation" id="En groupe" value="En groupe" required>En groupe
                    </label>
                    <label for="Club ECC" class="radio-inline">
                        <input type="radio" name="Typedereservation" id="Club ECC" value="Club ECC" required>Club ECC
                    </label>
                </div>
            </div>
            <div class="form-group">
                <label for="DateReservation">Date de réservation</label>
                <input type="date" id="DateReservation" name="DateReservation" required>
            </div>
            <div class="form-group">
                <label for="Heure">Heure de réservation</label>
                <input type="time" id="Heure" name="Heure" required>
            </div>
            <input type="submit" value="Enregistrer">
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $('#search-input').on('input', function() {
            var query = $(this).val();
            if (query.length > 1) {
                $.ajax({
                    url: 'suggestions.php',
                    method: 'GET',
                    data: { query: query },
                    success: function(data) {
                        $('#suggestions').html(data).show();
                    }
                });
            } else {
                $('#suggestions').hide();
            }
        });

        $(document).on('click', '.suggestion', function() {
            $('#search-input').val($(this).text());
            $('#suggestions').hide();
        });
    });
</script>
</body>
</html>
