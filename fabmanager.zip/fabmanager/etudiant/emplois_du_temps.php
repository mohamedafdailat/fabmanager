<?php
session_start();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FABMANAGER - Emplois du Temps</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f6f6f7;
            color: #2ec086;
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            align-items: center;
            background-color: #3ed8b4;
            color: #fbfbfb;
            padding: 20px;
        }

        #company-logo {
            height: 80px;
            width: auto;
            margin-right: 10px;
        }

        h1 {
            margin: 0;
            font-size: 1.5em;
        }

        nav {
            margin-left: auto;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fbfbfb;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            transition: color 0.3s ease;
        }

        nav ul li a:hover {
            background-color: #36bfb0;
        }

        main {
            display: flex;
            justify-content: center;
            align-items: center;
            height: calc(100vh - 60px); /* Ajustez la hauteur en fonction de la hauteur du header */
        }

        .content {
            display: flex;
            flex-direction: column;
            width: 100%;
            max-width: 800px;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .content img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
        }
    </style>
</head>
<body>
<header>
    <div class="header-content">
        <img src="logo.png" alt="Logo de l'entreprise" id="company-logo">
        <h1>Emplois du Temps</h1>
    </div>
    <nav>
        <ul>
            <li><a href="page_accueil.php"><i class="fas fa-home"></i> Accueil</a></li>
            <!-- <li><a href="reservermateriel.php"><i class="fas fa-calendar-alt"></i> Réserver le matériel</a></li> -->
            <li><a href="manipulation.php"><i class="fas fa-tasks"></i> Consulter les manipulations</a></li>
            <li><a href="autre_page.php"><i class="fas fa-info-circle"></i> À propos de nous</a></li>
            <li><a href="Mod.php"><i class="fas fa-user"></i> Profile</a></li>
            <li><a href="login.php"><i class="fas fa-sign-out-alt"></i> Déconnexion</a></li>
        </ul>
    </nav>
</header>
<main>
    <div class="content">
        <h2>Emploi du temps des créneaux disponibles</h2>
        <img src="emploi.png" alt="Emploi du temps">
    </div>
</main>
</body>
</html>
