<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <title>Manipulations et Matériels</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #e9ecef;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
        }

        header {
            background-color: #3ed8b4;
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: center;
        }
        nav ul li {
            display: inline;
            margin-right: 20px;
        }
        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            padding: 10px 15px;
            border-radius: 5px;
            background-color: #3ed8b4;
            transition: background-color 0.3s ease;
        }
        nav ul li a:hover {
            background-color: #36bfb0;
        }

        .container {
            max-width: 800px;
            margin: 30px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            flex: 1;
        }

        h1 {
            text-align: center;
            font-size: 1.8em;
            margin-bottom: 20px;
        }

        .search-container {
            text-align: center;
            margin-top: 20px;
        }

        .search-container input[type="text"] {
            width: 300px;
            padding: 10px;
            font-size: 16px;
            border-radius: 5px;
            border: 1px solid #ced4da;
        }

        .search-container button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-left: 10px;
        }

        .search-container button:hover {
            background-color: #218838;
        }

        .results {
            margin-top: 20px;
            text-align: center;
        }

        .results form {
            display: inline-block;
            margin: 10px 0;
        }

        .results button {
            padding: 10px 15px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            background-color: #007bff;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .results button:hover {
            background-color: #0056b3;
        }

        .suggestions {
            width: 300px;
            margin: 0 auto;
            border: 1px solid #ced4da;
            border-top: none;
            background-color: #fff;
            position: absolute;
            z-index: 1000;
            max-height: 200px;
            overflow-y: auto;
            border-radius: 0 0 5px 5px;
        }

        .suggestions p {
            padding: 10px;
            margin: 0;
            cursor: pointer;
        }

        header {
        display: flex;
        align-items: center; /* Alignement vertical au centre */
        background-color: #3ed8b4; /* Couleur de fond de l'en-tête */
        color: #fbfbfb; /* Couleur du texte de l'en-tête */
        padding: 20px;
        }

         #company-logo {
         height: 80px; /* Taille du logo */
         width: auto;
         margin-right: 10px; /* Espace à droite du logo */
        }

         h1 {
         margin: 20; /* Supprimer la marge pour éviter l'espace supplémentaire */
         font-size: 1.5em; /* Taille du titre augmentée */
        }

        nav {
            margin-left: auto; /* Aligner la nav à droite */
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fbfbfb;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            transition: color 0.3s ease;
        }

       nav ul li a:hover {
            background-color: #36bfb0;
        }
        .notification-icon:hover{
            background-color: #36bfb0;

        }  
        
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#search-input').on('input', function() {
                var query = $(this).val();
                if (query.length > 1) {
                    $.ajax({
                        url: 'suggestions.php',
                        method: 'GET',
                        data: { query: query },
                        success: function(data) {
                            $('#suggestions').html(data).show();
                        }
                    });
                } else {
                    $('#suggestions').hide();
                }
            });

            $(document).on('click', '.suggestion', function() {
                $('#search-input').val($(this).text());
                $('#suggestions').hide();
                updateResults();
            });

            function updateResults() {
                var query = $('#search-input').val();
                $.ajax({
                    url: 'ManipulationMatériel.php',
                    method: 'GET',
                    data: { query: query },
                    success: function(data) {
                        $('.results').html($(data).find('.results').html());
                    }
                });
            }

            $('form').on('submit', function(event) {
                event.preventDefault();
                updateResults();
            });
        });
    </script>
</head>
<body>
<header>
<img src="logo.png" alt="Logo de l'entreprise" id="company-logo">

    <h1>Tableau de bord - Étudiant</h1>
    <nav>
    <ul>
        <!-- <li><a href="">Accueil</a></li> -->
        <li><a href="page_accueil.php"><i class="fas fa-home"></i> Accueil</a></li>
        <!-- <li><a href="Reservation.php">Réserver un créneau </a></li> -->
        <li><a href="manipulation.php"><i class="fa-solid fa-microscope"></i> Consulter les manipulations</a></li>
        <li><a href="autre_page.php"><i class="fa-solid fa-info-circle"></i> À propos de nous</a></li>
        <li><a href="Mod.php"><i class="fa-solid fa-user"></i> Profile</a></li>
        <li><a href="login.php"><i class="fa-solid fa-sign-out-alt"></i> Déconnexion</a></li>
    </ul>
    </nav>
</header>
<?php
// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fabmanager";

$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

$query = isset($_GET['query']) ? $_GET['query'] : '';

$sql = "SELECT DISTINCT Nom_manipulation FROM manipulations WHERE Nom_manipulation LIKE ? OR LEFT(Nom_manipulation, 0) = ?";
$stmt = $conn->prepare($sql);
$search = '%' . $query . '%';
$search_first_letter = $query . '%';
$stmt->bind_param("ss", $search, $search_first_letter);
$stmt->execute();
$result = $stmt->get_result();
?>

<div class="container">
    <h1>Manipulations et Matériels</h1>
    <div class="search-container">
        <form action="ManipulationMatériel.php" method="get">
            <input type="text" id="search-input" placeholder="Rechercher..." name="query" value="<?php echo htmlspecialchars($query); ?>">
        </form>
        <div id="suggestions" class="suggestions"></div>
    </div>

    <div class="results">
        <?php if ($result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
                <form action="SelectManipulation.php" method="post">
                    <input type="hidden" name="selected_manipulation" value="<?php echo $row['Nom_manipulation']; ?>">
            
                    
            <?php endwhile; ?>
            <button style="background-color: #28a745" type="submit">Recherche</button>
    </form>
        <?php else: ?>
            <p>Aucun résultat trouvé.</p>
        <?php endif; ?>
    </div>
</div>

<?php
$stmt->close();
$conn->close();
?>

</body>
</html>
