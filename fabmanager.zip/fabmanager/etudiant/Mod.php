<?php
session_start();

// Vérification si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$database = "fabmanager";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Récupération des informations de l'utilisateur
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM utilisateur WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $username = $user['username'];
    $photo = $user['photo'];
} else {
    echo "Utilisateur non trouvé.";
    exit();
}
$stmt->close();

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_password = $_POST['current_password'];
    $new_username = $_POST['new_username'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Vérification que le mot de passe actuel est correct
    if ($current_password === $user['password']) { // Comparaison directe des mots de passe
        if ($new_password === $confirm_password) {
            $update_sql = "UPDATE utilisateur SET username = ?, password = ? WHERE id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("ssi", $new_username, $new_password, $user_id);
            if ($update_stmt->execute()) {
                $success_message = "Modification d'utilisateur mise à jour avec succès.";
                $username = $new_username;
            } else {
                $error_message = "Erreur lors de la mise à jour des informations.";
            }
            $update_stmt->close();
        } else {
            $error_message = "Les nouveaux mots de passe ne correspondent pas.";
        }
    } else {
        $error_message = "Mot de passe actuel incorrect.";
    }
}

// Récupérer le total des points et le classement de l'utilisateur
$sql = "SELECT point_total FROM classment WHERE utilisateur_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$points = 0;
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $points = $row['point_total'];
} else {
    echo "Aucune donnée trouvée pour l'utilisateur.";
}
$stmt->close();

// Récupérer le classement de l'utilisateur
$sql_rank = "SELECT utilisateur_id, point_total, FIND_IN_SET(point_total, (
    SELECT GROUP_CONCAT(point_total ORDER BY point_total DESC)
    FROM classment
)) AS rank FROM classment WHERE utilisateur_id = ?";
$stmt_rank = $conn->prepare($sql_rank);
$stmt_rank->bind_param("i", $user_id);
$stmt_rank->execute();
$result_rank = $stmt_rank->get_result();
$sql_rankings = "SELECT u.username, c.point_total 
                 FROM classment c 
                 JOIN utilisateur u ON c.utilisateur_id = u.id 
                 ORDER BY c.point_total DESC";
$result_rankings = $conn->query($sql_rankings);

$rankings = [];
if ($result_rankings->num_rows > 0) {
    while ($row = $result_rankings->fetch_assoc()) {
        $rankings[] = $row;
    }
} else {
    echo "Aucun classement trouvé.";
}
$rank = 0;
if ($result_rank->num_rows > 0) {
    $row_rank = $result_rank->fetch_assoc();
    $rank = $row_rank['rank'];
} else {
    echo "Classement non trouvé pour l'utilisateur.";
}
$stmt_rank->close();

// Récupérer le nombre total d'utilisateurs connectés
$sql_total_users = "SELECT COUNT(*) AS total FROM utilisateur";
$result_total_users = $conn->query($sql_total_users);
$total_users = 0;
if ($result_total_users->num_rows > 0) {
    $row_total_users = $result_total_users->fetch_assoc();
    $total_users = $row_total_users['total'];
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier le Nom d'Utilisateur et le Mot de Passe</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f6f6f7;
            color: #333;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #3ed8b4;
            color: #fff;
            padding: 20px;
            text-align: center;
            display: flex;
            align-items: center;
        }
        header img {
            height: 80px;
            width: auto;
            margin-right: 10px;
        }
        header h1 {
            font-size: 1.5em;
            margin: 0;
        }
        nav {
            margin-left: auto;
        }
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: center;
        }
        nav ul li {
            display: inline;
            margin-right: 20px;
        }
        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            padding: 10px 15px;
            border-radius: 5px;
            background-color: #3ed8b4;
            transition: background-color 0.3s ease;
        }
        nav ul li a:hover {
            background-color: #36bfb0;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 50px auto;
            text-align: center;
        }
        h2 {
            color: #333;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        input[type="text"], input[type="password"] {
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        .button {
            padding: 12px;
            background-color: #3ed8b4;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }
        .button:hover {
            background-color: #36bfb0;
        }
        .error {
            color: red;
            margin-top: 10px;
            text-align: center;
        }
        .success {
            color: green;
            margin-top: 10px;
            text-align: center;
        }
        main {
            padding: 20px;
        }
        .table {
            width: 100%;
            max-width: 600px;
            margin: auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-collapse: collapse;
        }
        .table td, .table th {
            padding: 10px;
            vertical-align: top;
            border: 1px solid #ddd;
            text-align: left;
        }
        .project-table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        .project-table td, .project-table th {
            padding: 10px;
            border: 1px solid #ddd;
        }
        img {
            display: block;
            margin: 10px auto;
            max-width: 100%;
            height: auto;
        }
        .project-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }
        .project-item {
            width: 48%;
            margin-bottom: 20px;
        }
        .section {
            display: flex;
            justify-content: space-evenly;
            flex-wrap: wrap;
        }
        .total {
            width: 45%;
        }
        .tof {
            display: flex;
            justify-content: space-between;
        }
        .img {
            width: 150px;
        }
        .al3zwa {
            border-radius: 50%;
        }
        .notification-icon:hover {
            background-color: #36bfb0;
        }
    </style>
</head>
<body>
<header>
    <img src="logo.png" alt="Logo de l'entreprise" id="company-logo">
    <h1>Tableau de bord - Étudiant</h1>
    <nav>
        <ul>
            <li><a href="page_accueil.php"><i class="fas fa-home"></i> Accueil</a></li>
            <li><a href="manipulation.php"><i class="fa-solid fa-microscope"></i> Consulter les manipulations</a></li>
            <li><a href="autre_page.php"><i class="fa-solid fa-info-circle"></i> À propos de nous</a></li>
            <li><a href="Mod.php"><i class="fa-solid fa-user"></i> Profil</a></li>
            <li><a href="login.php"><i class="fa-solid fa-sign-out-alt"></i> Déconnexion</a></li>
        </ul>
    </nav>
</header>
<section class="section">
    <div class="total">
        <div class="container">
            <h2>Modifier les données de l'utilisateur</h2>
            <div class="profile-photo">
                <?php if ($photo): ?>
                    <img src="<?php echo $photo; ?>" alt="Photo de profil">
                <?php else: ?>
                    <p>Aucune photo de profil</p>
                <?php endif; ?>
            </div>
            <form action="" method="post">
                <input type="text" name="new_username" placeholder="Nouveau nom d'utilisateur" value="<?= htmlspecialchars($username); ?>" required>
                <input type="password" name="current_password" placeholder="Mot de passe actuel" required>
                <input type="password" name="new_password" placeholder="Nouveau mot de passe" required>
                <input type="password" name="confirm_password" placeholder="Confirmer le mot de passe" required>
                <button type="submit" class="button">Mettre à Jour</button>
                <?php if (isset($error_message)) echo "<p class='error'>$error_message</p>"; ?>
                <?php if (isset($success_message)) echo "<p class='success'>$success_message</p>"; ?>
            </form>
            <table class="table">
                <tr>
                    <td>Mes points</td>
                    <td><?php echo $points; ?></td>
                </tr>
                <tr>
                    <td>Mon classement</td>
                    <td><?php echo $rank; ?></td>
                </tr>
            </table>
            <table class="table">
                <tr>
                    <th>Classement</th>
                    <th>Utilisateur</th>
                    <th>Points</th>
                </tr>
                <?php
                $rank = 1;
                foreach ($rankings as $ranking) {
                    echo "<tr>";
                    echo "<td>" . $rank . "</td>";
                    echo "<td>" . $ranking['username'] . "</td>";
                    echo "<td>" . $ranking['point_total'] . "</td>";
                    echo "</tr>";
                    $rank++;
                }
                ?>
            </table>
        </div>
    </div>
    <div class="total">
        <div class="container">
            <h2>PALMARÈS INNOVATION 2023</h2>
            <div class="tof">
                <img src="../brice.png" alt="Image 1" class="img adnane">
                <img src="../ja2iza.jpg" alt="Image 2" class="img">
            </div>
            <table class="table">
                <tr>
                    <td>Classement total :</td>
                    <td>1</td>
                </tr>
                <tr>
                    <td>Points totaux :</td>
                    <td>97</td>
                </tr>
                <tr>
                    <td>Prix :</td>
                    <td>Meilleur parcours innovatif</td>
                </tr>
            </table>
            <div class="project-container">
                <div class="project-item">
                    <h3>Parking rotatif vertical</h3>
                    <img src="../Parking.jpeg" alt="Parking rotatif vertical">
                </div>
                <div class="project-item">
                    <h3>Feux de circulation</h3>
                    <img src="../Feux de ciculation.jpeg" alt="Feux de circulation">
                </div>
                <div class="project-item">
                    <h3>Robot suiveur de ligne</h3>
                    <img src="../Robot suiveur de ligne.jpeg" alt="Robot suiveur de ligne">
                </div>
                <div class="project-item">
                    <h3>Circuit de Chua</h3>
                    <img src="../Circuit de chua.jpeg" alt="Circuit de Chua">
                </div>
                <div class="project-item">
                    <h3>Voiture télécommandée</h3>
                    <img src="../Voiture télécommandée.jpeg" alt="Voiture télécommandée">
                </div>
                <div class="project-item">
                    <h3>Robot d'exploration de mars</h3>
                    <img src="../Robot d'exploration de mars.jpeg" alt="Robot d'exploration de mars">
                </div>
            </div>
        </div>
    </div>
</section>
<style>
    .section {
        display: flex;
        justify-content: space-evenly;
    }
    .table, td {
        border: 1px solid;
    }
    .table {
        width: 100%;
        margin-top: 20px;
    }
    td {
        padding: 15px;
    }
    .tof {
        display: flex;
        justify-content: space-between;
    }
    .img {
        width: 150px;
    }
    .al3zwa {
        border-radius: 50%;
    }
    .ul li {
        text-align: start;
        margin: 5px 0;
    }
</style>
</body>
</html>