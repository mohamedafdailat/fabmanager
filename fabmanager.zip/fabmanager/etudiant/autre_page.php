<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Naviguer vers l'apprentissage</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Lien vers Font Awesome -->
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f6f6f7; /* Couleur de fond légère */
            color: #2ec086; /* Couleur de texte principale */
        }
        header {
            background-color: #3ed8b4; /* Couleur de fond de l'en-tête */
            color: #fbfbfb; /* Couleur du texte de l'en-tête */
            padding: 20px;
            text-align: center;
        }

        h1 {
            margin-bottom: 20px;
        }

        section {
            background-color: #fff; /* Couleur de fond des sections */
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 10px; /* Coins arrondis pour les sections */
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Ombre légère */
        }

        h2 {
            color: #3cd4d1; /* Couleur du titre de section */
            margin-bottom: 10px;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        li {
            margin-bottom: 10px;
        }

        a {
            text-decoration: none;
            color: #333;
        }

        a:hover {
            color: #FF0000; /* Couleur du texte du lien au survol */
        }

        i {
            margin-right: 5px; /* Marge à droite des icônes */
        }

        /* Styles spécifiques à la barre de navigation */
        nav {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px;
            background-color: #3ed8b4;
            color: #fff;
        }

        nav ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
            display: flex;
            align-items: center;
        }

        nav ul li {
            margin-right: 20px;
        }

        #company-logo {
            height: 60px; /* ajustez la hauteur selon votre besoin */
            margin-right: 20px;
        }
        header {
            display: flex;
            flex-wrap: wrap; /* Pour assurer la flexibilité sur les petits écrans */
            align-items: center;
            background-color: #3ed8b4;
            color: #fbfbfb;
            padding: 20px;
        }

        #company-logo {
            height: 80px;
            width: auto;
            margin-right: 10px;
        }

        h1 {
            margin: 0;
            font-size: 1.5em;
            flex: 1; /* Pour occuper l'espace restant */
        }

        nav {
            margin-left: auto;
            display: flex;
        }

        nav ul {
            display: flex;
            list-style-type: none;
            margin: 0;
            padding: 0;
        }

        nav ul li {
            margin-right: 10px;
        }

        nav ul li:last-child {
            margin-right: 0;
        }

        nav ul li a {
            text-decoration: none;
            color: #fbfbfb;
            font-weight: bold;
            padding: 5px 5px;
            border-radius: 5px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        nav ul li a:hover {
            background-color: #fbfbfb;
            color: #3ed8b4;
        }
       nav ul li a:hover {
            background-color: #36bfb0;
        }
    </style>
</head>
<body>
 
<header>
<img src="logo.png" alt="Logo de l'entreprise" id="company-logo">

    <h1>Tableau de bord - Étudiant</h1>
    <nav>
    <ul>
        <!-- <li><a href="">Accueil</a></li> -->
        <li><a href="page_accueil.php"><i class="fas fa-home"></i> Accueil</a></li>
        <!-- <li><a href="Reservation.php">Réserver un créneau </a></li> -->
        <li><a href="manipulation.php"><i class="fa-solid fa-microscope"></i> Consulter les manipulations</a></li>
        <li><a href="autre_page.php"><i class="fa-solid fa-info-circle"></i> À propos de nous</a></li>
        <li><a href="Mod.php"><i class="fa-solid fa-user"></i> Profile</a></li>
        <li><a href="login.php"><i class="fa-solid fa-sign-out-alt"></i> Déconnexion</a></li>
    </ul>
    </nav>
</header>
    <main>
        <section>
            <h2>Description du FABLAB:</h2>
            <p>Explorez davantage le FABLAB de l'école centrale casablanca à travers cette page. Découvrez des détails supplémentaires sur notre plateforme de production et de prototypage innovante et collaborative. Obtenez un aperçu approfondi de notre engagement envers une communauté de créateurs écoresponsables, ainsi que notre mission de partager des connaissances, des espaces et des outils pour l'innovation durable.</p>
        </section>
        <section>
            <h2>Liens Utiles:</h2>
            <ul>
                <li><a href="https://www.youtube.com/watch?v=cZZb6Oo5LHQ">À propos d'un Fablab <i class="fas fa-external-link-alt"></i></a></li>
                <li><a href="https://www.youtube.com/watch?v=GsEb9-W7oNA">Qu'est-ce qu'un Fab Lab ? What is a Fab Lab? <i class="fas fa-external-link-alt"></i></a></li>
                <li><a href="https://centrale-casablanca.ma/?s=fablab&lang=fr">FABALAB de l'école centrale centrale-casablanca <i class="fas fa-external-link-alt"></i></a></li>
            </ul>
        </section>
    </main>
    <footer>
        <div class="fablab-info">
            <h3>À propos du FabLab:</h3>
            <p>Le FabLab est un laboratoire de fabrication numérique ouvert à tous, où vous pouvez transformer vos idées en réalité. Doté d'équipements de pointe tels que des imprimantes 3D, des découpeuses laser et des machines CNC, le FabLab offre un environnement propice à l'innovation et à l'apprentissage collaboratif.</p>
            <p>Que vous soyez un professionnel, un étudiant ou un amateur passionné, le FabLab vous offre la possibilité d'explorer de nouvelles technologies, de prototyper des projets et de développer vos compétences en fabrication numérique.</p>
        </div>
        <div class="contact-info">
            <h3>Comment nous contacter:</h3>
            <p>Pour plus d'informations sur nos services, nos formations ou nos événements à venir, n'hésitez pas à nous contacter :</p>
            <ul>
                <li>Téléphone : +212 6 46 56 97 88</li>
                <li>Email : abdelaziz.daghouri@centrale-casablanca.ma</li>
                <li>Adresse : Ecole centrale casablanca, BOUSKOURA, MAROC</li>
            </ul>
        </div>
    </footer>
</body>
</html>
