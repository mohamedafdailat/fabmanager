<?php
// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fabmanager";

$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

$query = isset($_GET['query']) ? $_GET['query'] : '';

$sql = "SELECT DISTINCT Nom_manipulation FROM manipulations WHERE Nom_manipulation LIKE ? LIMIT 10";
$stmt = $conn->prepare($sql);
$search = '%' . $query . '%';
$stmt->bind_param("s", $search);
$stmt->execute();
$result = $stmt->get_result();

$suggestions = '';
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $suggestions .= '<p class="suggestion">' . htmlspecialchars($row['Nom_manipulation']) . '</p>';
    }
} else {
    $suggestions .= '<p>Aucun résultat trouvé.</p>';
}

echo $suggestions;

$stmt->close();
$conn->close();
?>
