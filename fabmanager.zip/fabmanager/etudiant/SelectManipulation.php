<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manipulations et Matériels</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f6f6f7;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            height: 100vh;
        }

        header {
            background: linear-gradient(to right, #3ed8b4, #36bfb0);
            color: #fff;
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: center;
            display: flex;
            justify-content: center;
        }

        nav ul li {
            margin: 0 15px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 5px;
            background-color: #3ed8b4;
            transition: background-color 0.3s ease;
        }

        nav ul li a:hover {
            background-color: #36bfb0;
        }

        .container {
            width: 100%;
            max-width: 900px;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin: 20px auto;
        }

        h1 {
            text-align: center;
            font-size: 1.8em;
            margin-bottom: 20px;
        }

        .search-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 30px;
        }

        .search-container input[type="text"] {
            width: 300px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
            outline: none;
            transition: border-color 0.3s ease;
        }

        .search-container input[type="text"]:focus {
            border-color: #5cb85c;
        }

        .search-container button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #5cb85c;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
            transition: background-color 0.3s ease;
        }

        .search-container button:hover {
            background-color: #4cae4c;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f8f9fa;
            color: #343a40;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #e9ecef;
        }

        .no-data {
            text-align: center;
            font-size: 18px;
            color: #888;
            margin-top: 20px;
        }

        .reserve-button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .reserve-button:hover {
            background-color: #0056b3;
        }
        header {
        display: flex;
        align-items: center; /* Alignement vertical au centre */
        background-color: #3ed8b4; /* Couleur de fond de l'en-tête */
        color: #fbfbfb; /* Couleur du texte de l'en-tête */
        padding: 20px;
        }

         #company-logo {
         height: 80px; /* Taille du logo */
         width: auto;
         margin-right: 10px; /* Espace à droite du logo */
        }

         h1 {
         margin: 20; /* Supprimer la marge pour éviter l'espace supplémentaire */
         font-size: 1.5em; /* Taille du titre augmentée */
        }

        nav {
            margin-left: auto; /* Aligner la nav à droite */
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fbfbfb;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            transition: color 0.3s ease;
        }

       nav ul li a:hover {
            background-color: #36bfb0;
        }
        .notification-icon:hover{
            background-color: #36bfb0;

        }
    </style>
</head>
<body>
<header>
<img src="logo.png" alt="Logo de l'entreprise" id="company-logo">

    <h1>Tableau de bord - Étudiant</h1>
    <nav>
    <ul>
        <!-- <li><a href="">Accueil</a></li> -->
        <li><a href="reservermatériel.php"><i class="fa-solid fa-calendar-check"></i> Réserver le matériel</a></li>
        <!-- <li><a href="Reservation.php">Réserver un créneau </a></li> -->
        <li><a href="manipulation.php"><i class="fa-solid fa-microscope"></i> Consulter les manipulations</a></li>
        <li><a href="autre_page.php"><i class="fa-solid fa-info-circle"></i> À propos de nous</a></li>
        <li><a href="Mod.php"><i class="fa-solid fa-user"></i> Profile</a></li>
        <li><a href="login.php"><i class="fa-solid fa-sign-out-alt"></i> Déconnexion</a></li>
    </ul>
    </nav>
</header>

<div class="container">
    <div id="result">
   <?php
// Database connection settings
$db_host = 'localhost';
$db_name = 'fabmanager';
$db_user = 'root';
$db_pass = '';

try {
    $conn = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $query = $_GET['query'] ?? '';

    if ($query) {
        $stmt = $conn->prepare("SELECT DISTINCT `Nom_manipulation` FROM `manipulations` WHERE `Nom_manipulation` LIKE ?");
        $stmt->execute(['%' . $query . '%']);
        $manipulations = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($manipulations) {
            echo "<form method='post' action='ManipulationMatériel.php'>";
            echo "<label for='selected_manipulation'>Sélectionnez une manipulation :</label>";
            echo "<select name='selected_manipulation' id='selected_manipulation' onchange='this.form.submit()'>";
            echo "<option value=''>-- Choisir une manipulation --</option>";
            foreach ($manipulations as $manipulation) {
                echo "<option value='{$manipulation['Nom_manipulation']}'>{$manipulation['Nom_manipulation']}</option>";
            }
            echo "</select>";
            echo "</form>";
        } else {
            echo "<p class='no-data'>Aucune manipulation trouvée pour votre recherche.</p>";
        }
    } elseif (isset($_POST['selected_manipulation'])) {
        $selected_manipulation = $_POST['selected_manipulation'];

        $stmt = $conn->prepare("SELECT `ID`, `Nom_manipulation`, `Matériels`, `Tutoriels`, `ModeEmploi`, `Quantitie` FROM `manipulations` WHERE `Nom_manipulation` = ?");
        $stmt->execute([$selected_manipulation]);
        $manipulations = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($manipulations) {
            echo "<h2>Détails de la manipulation : {$selected_manipulation}</h2>";
            echo "<table>";
            echo "<thead><tr><th>Matériels</th><th>Tutoriels</th><th>Mode d'emploi</th><th>Quantité</th><th>Disponibilité</th><th>Matériel alternative</th></tr></thead>";
            echo "<tbody>";
            foreach ($manipulations as $manipulation) {
                $material = $manipulation['Matériels'];
                $required_quantity = $manipulation['Quantitie'];

                // Check if the material exists in the 'matériels' table
                $materialStmt = $conn->prepare("SELECT `ID`, `NomMatériel`, `Disponibilité`, `Quantité`, `EmplacementFablab` FROM `matériels` WHERE `NomMatériel` = ?");
                $materialStmt->execute([$material]);
                $materialDetails = $materialStmt->fetch(PDO::FETCH_ASSOC);

                echo "<tr>";

                if ($materialDetails) {
                    $available_quantity = $materialDetails['Quantité'];
                    $location = $materialDetails['EmplacementFablab'];
                    $availability = $available_quantity >= $required_quantity ? 'Disponible' : 'Quantité insuffisante';

                    echo "<td>{$material}</td>";
                    echo "<td><a href='{$manipulation['Tutoriels']}' target='_blank'>Voir Tutoriel</a></td>";
                    echo "<td><a href='{$manipulation['ModeEmploi']}' target='_blank'>Voir Mode d'emploi</a></td>";
                    echo "<td>{$required_quantity}</td>";
                    echo "<td>{$availability}</td>";
                    if ($required_quantity > $available_quantity) {
                        echo "<td>{$location}</td>";
                    } else {
                        echo "<td></td>";
                    }
                } else {
                    echo "<td>{$material}</td>";
                    echo "<td><a href='{$manipulation['Tutoriels']}' target='_blank'>Voir Tutoriel</a></td>";
                    echo "<td><a href='{$manipulation['ModeEmploi']}' target='_blank'>Voir Mode d'emploi</a></td>";
                    echo "<td>{$required_quantity}</td>";
                    echo "<td>Matériel non existant</td>";
                    echo "<td></td>"; // Empty cell for location
                }
                echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";

            echo "<form method='post' action='ReserverAction2.php'>";
            foreach ($manipulations as $manipulation) {
                $material = $manipulation['Matériels'];
                $required_quantity = $manipulation['Quantitie'];
                $materialStmt = $conn->prepare("SELECT `ID`, `NomMatériel`, `Disponibilité`, `Quantité`, `EmplacementFablab` FROM `matériels` WHERE `NomMatériel` = ?");
                $materialStmt->execute([$material]);
                $materialDetails = $materialStmt->fetch(PDO::FETCH_ASSOC);

                echo "<input type='hidden' name='materials[]' value='{$material}'>";
                echo "<input type='hidden' name='quantities[]' value='{$required_quantity}'>";
                if ($materialDetails) {
                    echo "<input type='hidden' name='EmplacementFablab[]' value='{$materialDetails['EmplacementFablab']}'>";
                    echo "<input type='hidden' name='Disponibilite[]' value='" . ($materialDetails['Quantité'] >= $required_quantity ? 'Disponible' : 'Quantité insuffisante') . "'>";
                }
            }
            echo "<button type='submit' name='submit' class='reserve-button'>Ajouter au panier</button>";
            echo "</form>";
        } else {
            echo "<p class='no-data'>Aucune donnée trouvée pour cette manipulation.</p>";
        }
    } else {
        echo "<p class='no-data'>Veuillez effectuer une recherche pour voir les manipulations disponibles.</p>";
    }
} catch (PDOException $e) {
    echo "Erreur de connexion : " . $e->getMessage();
}
$conn = null;
?>

    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $('#search-input').on('input', function() {
            var query = $(this).val();
            if (query.length > 1) {
                $.ajax({
                    url: 'suggestions.php',
                    method: 'GET',
                    data: { query: query },
                    success: function(data) {
                        $('#suggestions').html(data).show();
                    }
                });
            } else {
                $('#suggestions').hide();
            }
        });

        $(document).on('click', '.suggestion', function() {
            $('#search-input').val($(this).text());
            $('#suggestions').hide();
        });
    });
</script>
</body>
</html>
