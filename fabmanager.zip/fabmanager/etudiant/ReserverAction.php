<?php
session_start();

// Vérifie si le panier existe dans la session, sinon le crée
if (!isset($_SESSION['panier'])) {
    $_SESSION['panier'] = [];
}

// Ajoute les matériels au panier lorsque le formulaire est soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
    if (isset($_POST['NomMatériel']) && isset($_POST['quantity'])) {
        // Ajoute un seul matériel avec sa quantité
        $materialName = $_POST['NomMatériel'];
        $quantity = $_POST['quantity'];

        $_SESSION['panier'][] = ['NomMatériel' => $materialName, 'Quantité' => $quantity];
    } elseif (isset($_POST['materials']) && isset($_POST['quantities'])) {
        // Ajoute plusieurs matériels avec leurs quantités
        $materials = $_POST['materials'];
        $quantities = $_POST['quantities'];

        for ($i = 0; $i < count($materials); $i++) {
            $material = $materials[$i];
            $quantity = $quantities[$i];

            $_SESSION['panier'][] = [
                'NomMatériel' => $material,
                'Quantité' => $quantity
            ];
        }
    }

    // Redirige vers la page panier.php
    header('Location: panier.php');
    exit;
} else {
    // Redirige vers la page précédente si le formulaire n'est pas soumis
    header('Location: ' . $_SERVER['HTTP_REFERER']);
    exit;
}
?>
