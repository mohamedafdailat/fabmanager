<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier la réservation</title>
    <style>
        /* Styles CSS ici */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        main {
            padding: 20px;
        }

        .modification {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .modification h2 {
            color: #333;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 10px;
        }

        input[type="text"],
        input[type="email"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #555;
        }

        footer {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

        footer p {
            margin-bottom: 10px;
        }

        footer ul {
            list-style-type: none;
            padding: 0;
        }

        footer ul li {
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Modifier la réservation</h1>
    </header>
    <main>
        <section class="modification">
            <h2>Modifier votre réservation</h2>
            <?php
            // Connexion à la base de données
            $servername = "localhost";
            $username = "root"; // Votre nom d'utilisateur MySQL
            $password = ""; // Votre mot de passe MySQL
            $dbname = "testing_res"; // Le nom de votre base de données

            // Créer la connexion
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Vérifier la connexion
            if ($conn->connect_error) {
                die("La connexion a échoué : " . $conn->connect_error);
            }

            // Récupérer l'identifiant de la réservation à partir de la requête GET
            $reservation_id = $_GET['id'];

            // Requête SQL pour récupérer les informations de réservation
            $sql = "SELECT * FROM reservation_base WHERE id = $reservation_id";

            // Exécuter la requête
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Afficher le formulaire de modification pré-rempli avec les informations de réservation
                while($row = $result->fetch_assoc()) {
                    echo "<form action='process_update_reservation.php' method='post'>";
                    echo "<label for='material'>Matériel :</label>";
                    echo "<input type='text' id='material' name='material' value='" . $row['material'] . "' required>";
                    echo "<label for='name'>Nom :</label>";
                    echo "<input type='text' id='name' name='name' value='" . $row['name'] . "' required>";
                    echo "<label for='email'>Email :</label>";
                    echo "<input type='email' id='email' name='email' value='" . $row['email'] . "' required>";
                    echo "<input type='hidden' name='reservation_id' value='" . $reservation_id . "'>";
                    echo "<input type='submit' value='Enregistrer les modifications'>";
                    echo "</form>";
                }
            } else {
                echo "Aucune réservation trouvée.";
            }
            ?>
        </section>
    </main>
    <footer>
     <div class="contact-info">
        <h3>Contactez-nous</h3>
        <p>Pour plus d'informations sur nos services, nos formations ou nos événements à venir, n'hésitez pas à nous contacter :</p>
        <ul>
            <li>Téléphone : +212 6 46 56 97 88</li>
            <li>Email : contact@fablab.com</li>
            <li>Adresse : Ecole Centrale Casablanca, Bouskoura, Maroc</li>
        </ul>
     </div>
    </footer>
</body>
</html>