<?php
session_start();

// Check if the user is logged in (adjust the condition based on your session management)
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id']; // Assuming user_id is stored in session when user logs in

$message = '';

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fabmanager";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve user information
$sql = "SELECT username, photo FROM utilisateur WHERE id='$user_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $current_username = $user['username'];
    $current_photo = $user['photo'];
} else {
    $message = "Utilisateur non trouvé.";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the input values and sanitize them
    $new_username = mysqli_real_escape_string($conn, $_POST['username']);
    $new_password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password']);

    // Check if passwords match
    if ($new_password !== $confirm_password) {
        $message = "Les mots de passe ne correspondent pas.";
    } else {
        // Hash the new password
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

        // Handle file upload if there is a photo file
        if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] == 0) {
            // Vérifier si le répertoire uploads existe, sinon le créer
            $uploadDir = 'uploads/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $photo_path = $uploadDir . basename($_FILES['avatar']['name']);
            move_uploaded_file($_FILES['avatar']['tmp_name'], $photo_path);
        } else {
            $photo_path = $current_photo;
        }

        // Update the user information in the database
        $sql = "UPDATE utilisateur SET username='$new_username', password='$hashed_password', photo='$photo_path' WHERE id='$user_id'";

        if ($conn->query($sql) === TRUE) {
            $message = "Profil mis à jour avec succès";
            $current_username = $new_username;
            $current_photo = $photo_path;
        } else {
            $message = "Erreur: " . $sql . "<br>" . $conn->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FABMANAGER - Modifier le profil</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Lien vers Font Awesome -->
    <style>
        /* Reset des styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Styles généraux */
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f8f8; /* Couleur de fond */
            color: #6e3434; /* Couleur du texte principal */
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        .notification {
            width: 100%;
            background-color: #4CAF50; /* Couleur de fond pour le succès */
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            top: 0;
            left: 0;
            display: none;
        }

        .notification.show {
            display: block;
        }

        .container {
            max-width: 400px;
            width: 100%;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 60px; /* Pour laisser de l'espace pour la notification */
        }

        header {
            background-color: #1b0d87; /* Couleur de fond de l'en-tête */
            color: #fff; /* Couleur du texte de l'en-tête */
            padding: 20px;
            text-align: center;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }

        h1 {
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="password"],
        input[type="file"] {
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            outline: none;
        }

        button {
            padding: 10px 20px;
            background-color: #1b0d87;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #0a0543;
        }

        .profile-photo {
            text-align: center;
            margin-bottom: 20px;
        }

        .profile-photo img {
            max-width: 100%;
            height: auto;
            border-radius: 50%;
        }
    </style>
</head>
<body>
    <div class="notification" id="notification">
        <?php echo $message; ?>
    </div>

    <div class="container">
        <header>
            <h1>FABMANAGER</h1>
        </header>
        <main>
            <section>
                <h2>Modifier le profil</h2>
                <div class="profile-photo">
                    <?php if ($current_photo): ?>
                        <img src="<?php echo $current_photo; ?>" alt="Photo de profil">
                    <?php else: ?>
                        <p>Aucune photo de profil</p>
                    <?php endif; ?>
                </div>
                <form action="" method="post" enctype="multipart/form-data">
                    <label for="username">Nom d'utilisateur :</label>
                    <input type="text" id="username" name="username" placeholder="Votre nom d'utilisateur" value="<?php echo htmlspecialchars($current_username); ?>" required>

                    <label for="password">Mot de passe :</label>
                    <input type="password" id="password" name="password" placeholder="Votre mot de passe" required>

                    <label for="confirm_password">Confirmer le mot de passe :</label>
                    <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirmez votre mot de passe" required>

                    <label for="avatar">Choisir un avatar :</label>
                    <input type="file" id="avatar" name="avatar" accept="image/*">

                    <button type="submit" name="submit">Enregistrer les modifications</button>
                </form>
            </section>
        </main>
    </div>

    <?php if ($message != ''): ?>
        <script>
            document.getElementById('notification').classList.add('show');
        </script>
    <?php endif; ?>
</body>
</html>
