<?php
session_start();

// Vérification si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$database = "fabmanager";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Récupération des informations de l'utilisateur
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM utilisateur WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $username = $user['username'];
    $id = $user['id'];
} else {
    echo "Utilisateur non trouvé.";
}
$stmt->close();

// Récupération des données du panier
$panier = $_SESSION['panier'] ?? [];

$material_status = [];
$material_names = array_column($panier, 'NomMatériel');
$placeholders = implode(',', array_fill(0, count($material_names), '?'));

$sql = "SELECT `NomMatériel`, `Disponibilité`, `Quantité`, `EmplacementFablab` FROM `matériels` WHERE `NomMatériel` IN ($placeholders)";
$stmt = $conn->prepare($sql);
$stmt->bind_param(str_repeat('s', count($material_names)), ...$material_names);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $material_status[$row['NomMatériel']] = $row;
}
$stmt->close();

// Vérification des quantités dans le panier
$warningMaterials = [];

foreach ($panier as $materialName => $details) {
    $quantityRequested = $details['Quantité'];
    $material_info = $material_status[$materialName] ?? null;
    if ($material_info && $quantityRequested > $material_info['Quantité']) {
        $warningMaterials[$materialName] = $material_info['EmplacementFablab'];
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Reservation.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Réservation créneau</title>
    <style>
        /* Styles généraux */
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f6f6f7;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #3ed8b4;
            color: #fff;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            background-color: #3ed8b4;
            transition: background-color 0.3s ease;
        }

        nav ul li a:hover {
            background-color: #36bfb0;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .card-header {
            background-color: #3ed8b4;
            color: #fff;
            padding: 20px;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            text-align: center;
        }

        .card-header h1 {
            margin: 0;
            font-size: 24px;
        }

        .card-body {
            padding: 20px;
        }

        .card-footer {
            background-color: #f0f0f0;
            padding: 10px;
            border-bottom-left-radius: 10px;
            border-bottom-right-radius: 10px;
            text-align: center;
        }

        h2 {
            color: #3cd4d1;
            margin-bottom: 10px;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }

        table th {
            background-color: #f2f2f2;
            color: #333;
        }

        form {
            display: grid;
            gap: 20px;
        }

        .form-group {
            display: grid;
            gap: 10px;
        }

        label {
            font-weight: bold;
            color: #555;
        }

        input[type="text"],
        input[type="time"],
        input[type="radio"],
        input[type="date"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        input[type="radio"] {
            width: auto;
            margin-right: 10px;
        }

        .radio-inline {
            display: inline-block;
            margin-right: 20px;
            font-size: 16px;
        }

        button,
        input[type="submit"] {
            padding: 12px 20px;
            background-color: #3ed8b4;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            font-size: 16px;
            font-weight: bold;
        }

        button:hover,
        input[type="submit"]:hover {
            background-color: #36bfb0;
        }

        .message {
            margin-bottom: 20px;
            padding: 15px;
            border-radius: 5px;
            background-color: #e0ffe0;
            color: #333;
            text-align: center;
        }

        .warning {
            background-color: #ffcccc;
            border-left: 5px solid #ff0000;
            padding: 10px;
            margin-top: 20px;
            border-radius: 5px;
            text-align: center;
        }

        header {
            display: flex;
            align-items: center;
            background-color: #3ed8b4;
            color: #fbfbfb;
            padding: 20px;
        }

        #company-logo {
            height: 80px;
            width: auto;
            margin-right: 10px;
        }

        h1 {
            margin: 0;
            font-size: 1.5em;
        }

        nav {
            margin-left: auto;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fbfbfb;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            transition: color 0.3s ease;
        }

        nav ul li a:hover {
            background-color: #36bfb0;
        }

        .notification-icon:hover {
            background-color: #36bfb0;
        }
    </style>
</head>
<body>
<header>
    <img src="logo.png" alt="Logo de l'entreprise" id="company-logo">
    <h1>Tableau de bord - Étudiant</h1>
    <nav>
        <ul>
            <li><a href="page_accueil.php"><i class="fas fa-home"></i> Accueil</a></li>
            <li><a href="manipulation.php"><i class="fa-solid fa-microscope"></i> Consulter les manipulations</a></li>
            <li><a href="autre_page.php"><i class="fa-solid fa-info-circle"></i> À propos de nous</a></li>
            <li><a href="Mod.php"><i class="fa-solid fa-user"></i> Profile</a></li>
            <li><a href="login.php"><i class="fa-solid fa-sign-out-alt"></i> Déconnexion</a></li>
        </ul>
    </nav>
</header>

<div class="container">
    <div class="card">
        <div class="card-header">
            <h1>Formulaire de réservations</h1>
        </div>
        <div class="card-body">
            <?php
            // Affichage du panier et du message de succès
            if (!empty($panier)) {
                echo "<h2>Votre panier :</h2>";
                echo "<table>";
                echo "<tr><th>Quantité</th><th>Matériel</th></tr>";
                foreach ($panier as $reservation) {
                    $materialName = $reservation['NomMatériel'];
                    $quantity = $reservation['Quantité'];
                    $material_info = $material_status[$materialName] ?? null;
                    $display_name = $material_info && $material_info['Disponibilité'] ? $materialName : $material_info['EmplacementFablab'] ?? $materialName;
                    echo "<tr><td>$quantity</td><td>$display_name</td></tr>";
                }
                echo "</table>";

                // Vérification des quantités
                if (!empty($warningMaterials)) {
                    echo "<div class='warning'>";
                    echo "<strong>Attention :</strong> Certaines quantités demandées dépassent la disponibilité des matériaux.";
                    echo "<ul>";
                    foreach ($warningMaterials as $material => $location) {
                        echo "<li>$material : $location</li>";
                    }
                    echo "</ul>";
                    echo "</div>";
                }
            } else {
                echo "<p>Votre panier est vide.</p>";
            }

            if (isset($success_message)) {
                echo "<div class='message'>$success_message</div>";
            }
            ?>

            <form action="Reservation1.php" method="post">
                <input type="hidden" id="UserID" name="UserID" value="<?php echo htmlspecialchars($id); ?>">

                <div class="form-group">
                    <label for="NomResponsable">Nom complet du responsable</label>
                    <input type="text" id="NomResponsable" name="NomResponsable" value="<?php echo htmlspecialchars($username); ?>" required>
                </div>
                <div class="form-group">
                    <label for="Typedereservation">Type de réservation</label>
                    <div>
                        <label for="individuel" class="radio-inline">
                            <input type="radio" name="Typedereservation" id="individuel" value="Individuel" required>Individuel
                        </label>
                        <label for="En_groupe" class="radio-inline">
                            <input type="radio" name="Typedereservation" id="En_groupe" value="En groupe" required>En groupe
                        </label>
                        <label for="Club_ECC" class="radio-inline">
                            <input type="radio" name="Typedereservation" id="Club_ECC" value="Club ECC" required>Club ECC
                        </label>
                    </div>
                </div>
                <div class="form-group">
                    <label for="DateReservation">Date de réservation</label>
                    <input type="date" id="DateReservation" name="DateReservation" required>
                </div>
                <div class="form-group">
                    <label for="Heure">Heure de réservation</label>
                    <input type="time" id="Heure" name="Heure" required>
                </div>
                <input type="submit" value="Enregistrer">
            </form>
        </div>
        <div class="card-footer">
            <small>&copy;Fabmanager 2024</small>
        </div>
    </div>
</div>
</body>
</html>

<?php
$conn->close();
?>
