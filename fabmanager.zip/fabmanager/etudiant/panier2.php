<?php
// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";  // Assurez-vous que ce soit votre mot de passe correct
$dbname = "fabmanager";  // Remplacez par le nom de votre base de données

// Création de la connexion
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérification de la connexion
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Gestion des actions du panier
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['submit'])) {
        $_SESSION['panier'] = $_POST['panier'];
        $success_message = "Matériel ajouté au panier avec succès !";
        $reserve_slot_message = "<p>Si vous souhaitez réserver un créneau, veuillez cliquer sur le bouton ci-dessous :</p>";
    } elseif (isset($_POST['empty_cart'])) {
        $_SESSION['panier'] = [];
        $success_message = "Le panier a été vidé avec succès !";
        header("Location: panier.php");
        exit;
    }
}

// Vérification de l'existence des matériels dans le panier
$material_status = [];
if (isset($_SESSION['panier']) && !empty($_SESSION['panier'])) {
    $ids = array_column($_SESSION['panier'], 'NomMatériel');
    $placeholders = implode(',', array_fill(0, count($ids), '?'));

    $sql = "SELECT `ID`, `NomMatériel`, `Disponibilité`, `Quantité`, `EmplacementFablab`, `Image`, `Description` 
            FROM `matériels` 
            WHERE `NomMatériel` IN ($placeholders)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param(str_repeat('s', count($ids)), ...$ids);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $material_status[$row['NomMatériel']] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Votre panier</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f6f6f7;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #3ed8b4;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            background-color: #3ed8b4;
            transition: background-color 0.3s ease;
        }

        nav ul li a:hover {
            background-color: #36bfb0;
        }

        main {
            padding: 20px;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        section {
            background-color: #fff;
            padding: 20px;
            margin: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        h2 {
            color: #3cd4d1;
            margin-bottom: 10px;
            text-align: center;
        }

        ul {
            list-style-type: none;
            padding: 0;
            text-align: left;
        }

        li {
            margin-bottom: 10px;
        }

        .button-container {
            text-align: center;
            margin-top: 20px;
            display: flex;
            justify-content: space-between;
        }

        .button {
            padding: 10px 20px;
            background-color: grey;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            flex-grow: 1;
        }

        .button:hover {
            background-color: #36bfb0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #3ed8b4;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .separator {
            border-right: 1px solid #ddd;
            padding: 0;
            width: 10px;
        }

        .no-availability {
            background-color: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
            margin-top: 10px;
        }

        .available {
            background-color: #d4edda;
            color: #155724;
        }

        .unavailable {
            background-color: #f8d7da;
            color: #721c24;
        }
        header {
        display: flex;
        align-items: center; /* Alignement vertical au centre */
        background-color: #3ed8b4; /* Couleur de fond de l'en-tête */
        color: #fbfbfb; /* Couleur du texte de l'en-tête */
        padding: 20px;
        }

         #company-logo {
         height: 80px; /* Taille du logo */
         width: auto;
         margin-right: 10px; /* Espace à droite du logo */
        }

         h1 {
         margin: 20; /* Supprimer la marge pour éviter l'espace supplémentaire */
         font-size: 1.5em; /* Taille du titre augmentée */
        }

        nav {
            margin-left: auto; /* Aligner la nav à droite */
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fbfbfb;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            transition: color 0.3s ease;
        }

       nav ul li a:hover {
            background-color: #36bfb0;
        }
        .notification-icon:hover{
            background-color: #36bfb0;

        }
    </style>
</head>
<body>
<header>
    <img src="logo.png" alt="Logo de l'entreprise" id="company-logo">
    <h1>Tableau de bord - Étudiant</h1>
    <nav>
    <ul>
        <li><a href="reservermatériel.php"><i class="fa-solid fa-calendar-check"></i> Réserver le matériel</a></li>
        <li><a href="manipulation.php"><i class="fa-solid fa-microscope"></i> Consulter les manipulations</a></li>
        <li><a href="autre_page.php"><i class="fa-solid fa-info-circle"></i> À propos de nous</a></li>
        <li><a href="Mod.php"><i class="fa-solid fa-user"></i> Profile</a></li>
        <li><a href="login.php"><i class="fa-solid fa-sign-out-alt"></i> Déconnexion</a></li>
    </ul>
    </nav>
</header>
    <?php
    if (isset($success_message)) {
        echo "<p>$success_message</p>";
    }
    ?>

    <main>
        <h2>Votre panier</h2>
        <table>
            <thead>
                <tr>
                    <th>Nom du Matériel</th>
                    <th>Quantité</th>
                    <th>Disponibilité</th>
                    <th>Matériel alternative </th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (isset($_SESSION['panier']) && !empty($_SESSION['panier'])) {
                    foreach ($_SESSION['panier'] as $item) {
                        $materialName = $item['NomMatériel'];
                        $quantity = $item['Quantité'];
                        $availability = isset($material_status[$materialName]) ? 
                            ($material_status[$materialName]['Quantité'] >= $quantity ? 'Disponible' : 'Quantité insuffisante') : 
                            'Inconnu';
                        $location = isset($material_status[$materialName]) ? $material_status[$materialName]['EmplacementFablab'] : 'Non disponible';

                        echo "<tr>";
                        echo "<td>{$materialName}</td>";
                        echo "<td>{$quantity}</td>";
                        echo "<td " . ($availability === 'Disponible' ? "class='available'" : "class='unavailable'") . ">{$availability}</td>";
                        if ($availability !== 'Disponible') {
                            echo "<td>{$location}</td>";
                        } else {
                            echo "<td></td>";
                        }
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>Votre panier est vide.</td></tr>";
                }
                ?>
            </tbody>
        </table>
        <div class="button-container">
          <?php

        echo '<div class="button-container">';
        echo '<form action="reservermatériel.php" method="post">';
        echo '<input type="submit" name="add_another" value="Ajouter un autre matériel" class="button">';
        echo '</form>';
         echo '&nbsp;';
        echo '<form action="panier.php" method="post">';
        echo '<input type="submit" name="empty_cart" value="Vider le panier" class="button">';
        echo '</form>';
        echo '&nbsp;';
        echo '<form action="Reservation.php" method="post">';
        echo '<input type="submit" name="reserve_slot" value="Réserver un créneau" class="button">';
        echo '</form>';
        echo '</div>';
 
        // echo "<p>Votre panier est vide.</p>";
        // echo '<form action="reservermatériel.php" method="post">';
        // echo '<input type="submit" name="add_another" value="Ajouter un autre matériel" class="button">';
        // echo '</form>';
   
    ?>
        </div>
    </main>
</body>
</html>
<?php
$conn->close();
?>
