<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hover 3D Animation || Web Addicted</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        /* Styles généraux */
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f6f6f7;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #3ed8b4;
            color: #fff;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            background-color: #3ed8b4;
            transition: background-color 0.3s ease;
        }

        nav ul li a:hover {
            background-color: #36bfb0;
        }

        .search-container {
            text-align: center;
            margin: 20px 0;
        }

        .search-container input {
            padding: 10px;
            width: 300px;
            border: 1px solid #ddd;
            border-radius: 5px;
            outline: none;
            transition: border-color 0.3s ease;
        }

        .search-container input:focus {
            border-color: #3ed8b4;
        }

        .card-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            padding: 20px;
        }

        .card {
            width: calc(25% - 20px);
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin: 10px;
            overflow: hidden;
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card-content {
            padding: 20px;
            text-align: center;
            height: 100%;
        }

        .card-front {
            background-color: #3ed8b4;
            color: #fff;
            padding: 20px;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }

        .card-front h1 {
            font-size: 1.5rem;
            margin: 0;
        }

        .card-back {
            padding: 20px;
            background-color: #fff;
            border-bottom-left-radius: 10px;
            border-bottom-right-radius: 10px;
        }

        .title {
            font-family: 'Teko', sans-serif;
            font-size: 1.5rem;
            text-transform: uppercase;
            line-height: 120%;
            color: #fff;
        }

        .btn {
            outline: none;
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 1.8rem;
            color: #fff;
            background-color: #3ed8b4;
            border: 2px solid #fff;
            border-radius: 100px;
            text-align: center;
            margin-top: 1rem;
            transition: background-color 0.3s ease;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #36bfb0;
        }

        @media (max-width: 1200px) {
            .card {
                width: calc(33.33% - 20px);
            }
        }

        @media (max-width: 900px) {
            .card {
                width: calc(50% - 20px);
            }
        }

        @media (max-width: 600px) {
            .card {
                width: calc(100% - 20px);
            }
        }
        header {
        display: flex;
        align-items: center; /* Alignement vertical au centre */
        background-color: #3ed8b4; /* Couleur de fond de l'en-tête */
        color: #fbfbfb; /* Couleur du texte de l'en-tête */
        padding: 20px;
        }

         #company-logo {
         height: 80px; /* Taille du logo */
         width: auto;
         margin-right: 10px; /* Espace à droite du logo */
        }

         h1 {
         margin: 20; /* Supprimer la marge pour éviter l'espace supplémentaire */
         font-size: 1.5em; /* Taille du titre augmentée */
        }

        nav {
            margin-left: auto; /* Aligner la nav à droite */
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fbfbfb;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            transition: color 0.3s ease;
        }

       nav ul li a:hover {
            background-color: #36bfb0;
        }
        .notification-icon:hover{
            background-color: #36bfb0;

        }  
        header {
        display: flex;
        align-items: center; /* Alignement vertical au centre */
        background-color: #3ed8b4; /* Couleur de fond de l'en-tête */
        color: #fbfbfb; /* Couleur du texte de l'en-tête */
        padding: 20px;
        }

         #company-logo {
         height: 80px; /* Taille du logo */
         width: auto;
         margin-right: 10px; /* Espace à droite du logo */
        }

         h1 {
         margin: 20; /* Supprimer la marge pour éviter l'espace supplémentaire */
         font-size: 1.5em; /* Taille du titre augmentée */
        }

        nav {
            margin-left: auto; /* Aligner la nav à droite */
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fbfbfb;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            transition: color 0.3s ease;
        }

       nav ul li a:hover {
            background-color: #36bfb0;
        }
        .notification-icon:hover{
            background-color: #36bfb0;

        }  
    </style>
</head>
<body>
<header>
<img src="logo.png" alt="Logo de l'entreprise" id="company-logo">

    <h1>Tableau de bord - Étudiant</h1>
    <nav>
    <ul>
        <!-- <li><a href="">Accueil</a></li> -->
        <li><a href="page_accueil.php"><i class="fas fa-home"></i> Accueil</a></li>
        <!-- <li><a href="Reservation.php">Réserver un créneau </a></li> -->
        <li><a href="manipulation.php"><i class="fa-solid fa-microscope"></i> Consulter les manipulations</a></li>
        <li><a href="autre_page.php"><i class="fa-solid fa-info-circle"></i> À propos de nous</a></li>
        <li><a href="Mod.php"><i class="fa-solid fa-user"></i> Profile</a></li>
        <li><a href="login.php"><i class="fa-solid fa-sign-out-alt"></i> Déconnexion</a></li>
    </ul>
    </nav>
</header>
    <div class="search-container">
        <input type="text" id="searchInput" placeholder="Rechercher une vidéo..." onkeyup="searchVideos()">
    </div>
    <div class="card-container">
        <div class="card" data-title="Expérience de Frank Hertz">
            <div class="card-content">
                <div class="card-front">
                    <h1 class="title">Expérience de Frank Hertz</h1>
                </div>
                <div class="card-back">
                    <div id="video1"></div>
                    <button class="btn" onclick="startVideo('video1', 'Ymxw8R4DJus')">Regarder la manipulation</button>
                </div>
            </div>
        </div>
        <div class="card" data-title="Effet photoelectrique">
            <div class="card-content">
                <div class="card-front">
                    <h1 class="title">Effet photoelectrique</h1>
                </div>
                <div class="card-back">
                    <div id="video2"></div>
                    <button class="btn" onclick="startVideo('video2', 'Ux1lk4IarwE')">Regarder la manipulation</button>
                </div>
            </div>
        </div>
        <div class="card" data-title="Le robot ultime Rasberry Pi 4">
            <div class="card-content">
                <div class="card-front">
                    <h1 class="title">Le robot ultime Rasberry Pi 4</h1>
                </div>
                <div class="card-back">
                    <div id="video3"></div>
                    <button class="btn" onclick="startVideo('video3', 'Zdv4cOmOmb8')">Regarder la manipulation</button>
                </div>
            </div>
        </div>
        <div class="card" data-title="Utiliser le capteur d'humidité avec l'Arduino Uno">
            <div class="card-content">
                <div class="card-front">
                    <h1 class="title">Utiliser le capteur d'humidité avec l'Arduino Uno</h1>
                </div>
                <div class="card-back">
                    <div id="video4"></div>
                    <button class="btn" onclick="startVideo('video4', '-HCZY4UoFiA')">Regarder la manipulation</button>
                </div>
            </div>
        </div>
        <div class="card" data-title="Calcul de l'angle de déviation minimale">
            <div class="card-content">
                <div class="card-front">
                    <h1 class="title">Calcul de l'angle de déviation minimale</h1>
                </div>
                <div class="card-back">
                    <div id="video5"></div>
                    <button class="btn" onclick="startVideo('video5', 'JGnNRZtQYhM')">Regarder la manipulation</button>
                </div>
            </div>
        </div>
    </div>
    <script>
        function startVideo(containerId, videoId) {
            const container = document.getElementById(containerId);
            container.innerHTML = `<iframe width="100%" height="315" src="https://www.youtube.com/embed/${videoId}?autoplay=1" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>`;
            const button = container.nextElementSibling;
            button.parentNode.removeChild(button);
        }

        function searchVideos() {
            const input = document.getElementById('searchInput').value.toLowerCase();
            const cards = document.querySelectorAll('.card');

            cards.forEach(card => {
                const title = card.getAttribute('data-title').toLowerCase();
                if (title.includes(input)) {
                    card.style.display = '';
                } else {
                    card.style.display = 'none';
                }
            });
        }
    </script>
</body>
</html>
