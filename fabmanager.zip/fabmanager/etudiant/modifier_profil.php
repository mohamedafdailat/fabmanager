<?php
session_start();

// Check if the user is logged in (adjust the condition based on your session management)
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id']; // Assuming user_id is stored in session when user logs in

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "fabmanager";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get the input values and sanitize them
    $new_username = mysqli_real_escape_string($conn, $_POST['username']);
    $new_password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password']);

    // Check if passwords match
    if ($new_password !== $confirm_password) {
        echo "Les mots de passe ne correspondent pas.";
        exit();
    }

    // Hash the new password
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

    // Handle file upload if there is a photo file
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
        $photo_path = 'uploads/' . basename($_FILES['photo']['name']);
        move_uploaded_file($_FILES['photo']['tmp_name'], $photo_path);
    } else {
        $photo_path = NULL;
    }

    // Update the user information in the database
    if ($photo_path) {
        $sql = "UPDATE utilisateur SET username='$new_username', password='$hashed_password', photo='$photo_path' WHERE id='$user_id'";
    } else {
        $sql = "UPDATE utilisateur SET username='$new_username', password='$hashed_password' WHERE id='$user_id'";
    }

    if ($conn->query($sql) === TRUE) {
        echo "Profil mis à jour avec succès";
    } else {
        echo "Erreur: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
