<?php
$con = mysqli_connect("localhost", "root", "", "fabmanager") or die ("erreur de connection");
$query = "SELECT * FROM utilisateur";
$result = mysqli_query($con, $query) or die ("erreur de requette");
$rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Table</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f6f6f7;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #3ed8b4;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            background-color: #3ed8b4;
            transition: background-color 0.3s ease;
        }

        nav ul li a:hover {
            background-color: #36bfb0;
        }

        .user-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .user-table th, .user-table td {
            padding: 8px;
            border: 1px solid #ddd;
        }

        .user-table th {
            background-color: #3ed8b4;
            color: white;
            font-weight: bold;
        }

        .user-table tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .user-table tr:hover {
            background-color: #ddd;
        }

        .btn {
            text-decoration: none;
            color: white;
            background-color: #f0ad4e;
            padding: 5px 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #ec971f;
        }

        .btn-danger {
            background-color: #d9534f;
        }

        .btn-danger:hover {
            background-color: #c9302c;
        }
    </style>
</head>
<body>
<header>
    <h1>Tableau de bord - Etudiant</h1>
    <nav>
        <ul>
            <li><a href="page_accueil.php">Accueil</a></li>
            <li><a href="Reservation.php">Réserver un créneau</a></li>
            <li><a href="manipulation.php">Consulter les manipulations</a></li>
            <li><a href="login.php">Déconnexion</a></li>
        </ul>
    </nav>
</header>
<h1 style="text-align: center;">Liste d'utilisateurs</h1>
<table class="user-table">
    <tr>
        <th>id</th>
        <th>username</th>
        <th>password</th>
        <th>action</th>
    </tr>
    <?php foreach($rows as $row) : ?>
    <tr>
        <td><?= htmlspecialchars($row['id']) ?></td>
        <td><?= htmlspecialchars($row['username']) ?></td>
        <td><?= htmlspecialchars($row['password']) ?></td>
        <td>
            <a class="btn" href="edit.php?id=<?= $row['id'] ?>">Edit</a>
            <a class="btn btn-danger" href="delete.php?id=<?= $row['id'] ?>" onclick="return confirm('Are you sure you want to delete this user?');">Supprimer</a>
        </td>
    </tr>
    <?php endforeach ?>
</table>
</body>
</html>
