<?php
$con = mysqli_connect("localhost", "root", "", "fabmanager") or die ("Erreur de connexion");

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    $query = "DELETE FROM utilisateur WHERE id = ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute() or die("Erreur de requête");
    
    header("Location: listutulisateurs.php");
    exit();
} else {
    die("ID not provided");
}
?>
