<?php
$con = mysqli_connect("localhost", "root", "", "fabmanager") or die ("Erreur de connection");
$query = "SELECT * FROM utilisateur";
$result = mysqli_query($con, $query) or die ("Erreur de requête");
$rows = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Fetch project links for display
$projectLinksQuery = "SELECT * FROM project_links";
$projectLinksResult = mysqli_query($con, $projectLinksQuery) or die("Erreur de requête");
$projectLinks = mysqli_fetch_all($projectLinksResult, MYSQLI_ASSOC);

// Map usernames to user IDs
$usernames = [];
foreach ($rows as $row) {
    $usernames[$row['id']] = $row['username'];
}

// Regrouper les projets par nom de projet
$projects = [];
foreach ($projectLinks as $link) {
    $projects[$link['nomprojet']][] = $usernames[$link['idetudiant']];
}

// Suppression de projet
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['deleteId'])) {
    $deleteId = intval($_POST['deleteId']);
    $stmt = $con->prepare("DELETE FROM project_links WHERE id = ?");
    $stmt->bind_param("i", $deleteId);
    if ($stmt->execute()) {
        echo "<p style='color: green;'>Projet supprimé avec succès!</p>";
    } else {
        echo "<p style='color: red;'>Erreur lors de la suppression du projet: " . $stmt->error . "</p>";
    }
    $stmt->close();
}
mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes Projets Liés</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f6f6f7;
            color: #2ec086;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #3ed8b4;
            color: #fbfbfb;
            padding: 20px;
            text-align: center;
        }
        main {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
        }
        .form-container, .projects-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            width: 100%;
            max-width: 600px;
        }
        .form-container h2, .projects-container h2 {
            color: #3cd4d1;
            margin-bottom: 20px;
            text-align: center;
        }
        .form-container form, .projects-container ul {
            display: flex;
            flex-direction: column;
        }
        .form-container label, .projects-container li {
            margin-bottom: 10px;
        }
        .form-container input, .form-container select, .form-container button {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .form-container button {
            background-color: #3ed8b4;
            color: #fff;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .form-container button:hover {
            background-color: #36bfb0;
        }
        .projects-container ul {
            list-style-type: none;
            padding: 0;
        }
        .projects-container li {
            padding: 15px;
            background-color: #f6f6f7;
            border-radius: 5px;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .projects-container li .project-info {
            flex: 1;
        }
        .projects-container li .actions {
            display: flex;
            align-items: center;
        }
        .projects-container li i {
            color: #3ed8b4;
            cursor: pointer;
            margin-left: 10px;
        }
        .projects-container li i:hover {
            color: #2ec086;
        }
        header {
        display: flex;
        align-items: center; /* Alignement vertical au centre */
        background-color: #3ed8b4; /* Couleur de fond de l'en-tête */
        color: #fbfbfb; /* Couleur du texte de l'en-tête */
        padding: 20px;
        }

         #company-logo {
         height: 80px; /* Taille du logo */
         width: auto;
         margin-right: 10px; /* Espace à droite du logo */
        }

         h1 {
         margin: 20; /* Supprimer la marge pour éviter l'espace supplémentaire */
         font-size: 1.5em; /* Taille du titre augmentée */
        }

        nav {
            margin-left: auto; /* Aligner la nav à droite */
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fbfbfb;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            transition: color 0.3s ease;
        }

       nav ul li a:hover {
            background-color: #36bfb0;
        }
        .notification-icon:hover{
            background-color: #36bfb0;

        }
        @media (max-width: 600px) {
    header {
        padding: 15px;
    }}
    </style>
</head>
<body>
<header>
<img src="logo.png" alt="Logo de l'entreprise" id="company-logo">

    <h1>Tableau de bord - Étudiant</h1>
    <nav>
    <ul>
        <!-- <li><a href="">Accueil</a></li> -->
        <li><a href="reservermatériel.php"><i class="fa-solid fa-calendar-check"></i> Réserver le matériel</a></li>
        <!-- <li><a href="Reservation.php">Réserver un créneau </a></li> -->
        <li><a href="manipulation.php"><i class="fa-solid fa-microscope"></i> Consulter les manipulations</a></li>
        <li><a href="autre_page.php"><i class="fa-solid fa-info-circle"></i> À propos de nous</a></li>
        <li><a href="Mod.php"><i class="fa-solid fa-user"></i> Profile</a></li>
        <li><a href="login.php"><i class="fa-solid fa-sign-out-alt"></i> Déconnexion</a></li>
    </ul>
    </nav>
</header>

    <main>
        <div class="form-container">
            <h2>Lier un projet</h2>
            <form method="POST">
                <label for="projectId">Nom du Projet</label>
                <input type="text" id="projectId" name="nomprojet" required>
                
                <label for="selectedStudents">Sélectionner les Étudiants</label>
                <select name="selectedStudents[]" id="selectedStudents" multiple>
                    <?php foreach($rows as $row):?>
                        <option value="<?=$row['id']?>"><?=$row['username']?></option>
                    <?php endforeach ?>
                </select>
                <button type="submit">Lier le Projet</button>
            </form>
        </div>
        
        <?php
        $con = mysqli_connect("localhost", "root", "", "fabmanager") or die("Erreur de connection");

        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['nomprojet']) && isset($_POST['selectedStudents'])) {
            $nomprojet = mysqli_real_escape_string($con, $_POST['nomprojet']);
            $selectedStudents = $_POST['selectedStudents'];

            foreach ($selectedStudents as $studentId) {
                $studentId = mysqli_real_escape_string($con, $studentId);
                $query = "INSERT INTO project_links (idetudiant, nomprojet) VALUES ('$studentId', '$nomprojet')";
                if (!mysqli_query($con, $query)) {
                    echo "<p style='color: red;'>Erreur lors de la liaison du projet: " . mysqli_error($con) . "</p>";
                }
            }
            echo "<p style='color: green;'>Projet lié avec succès!</p>";
        }

        $query = "SELECT * FROM utilisateur";
        $result = mysqli_query($con, $query) or die("Erreur de requête");
        $rows = mysqli_fetch_all($result, MYSQLI_ASSOC);

        $projectLinksQuery = "SELECT * FROM project_links";
        $projectLinksResult = mysqli_query($con, $projectLinksQuery) or die("Erreur de requête");
        $projectLinks = mysqli_fetch_all($projectLinksResult, MYSQLI_ASSOC);

        // Map usernames to user IDs
        $usernames = [];
        foreach ($rows as $row) {
            $usernames[$row['id']] = $row['username'];
        }

        // Regrouper les projets par nom de projet
        $projects = [];
        foreach ($projectLinks as $link) {
            $projects[$link['nomprojet']][] = $usernames[$link['idetudiant']];
        }

        mysqli_close($con);
        ?>

        <div class="projects-container">
            <h2>Projets Liés</h2>
            <ul>
                <?php foreach ($projects as $projectName => $students) : ?>
                    <li>
                        <div class="project-info">
                            <h3><?= htmlspecialchars($projectName) ?></h3>
                            <ul>
                                <?php foreach ($students as $studentName) : ?>
                                    <li>Étudiant: <?= htmlspecialchars($studentName) ?></li>
                                <?php endforeach ?>
                            </ul>
                        </div>
                        <div class="actions">
                            <form method='POST' style='display:inline;' onsubmit='return confirm("Voulez-vous vraiment supprimer ce projet lié?");'>
                                <input type='hidden' name='deleteId' value='<?= htmlspecialchars($link['id']) ?>'>
                                <button type='submit' style='background:none; border:none; color:#3ed8b4; cursor:pointer;'><i class='fas fa-trash-alt'></i></button>
                            </form>
                        </div>
                    </li>
                <?php endforeach ?>
            </ul>
        </div>
    </main>
</body>
</html>
