<?php
session_start();

// Connexion à la base de données
$servername = "localhost";
$username = "root"; // Votre nom d'utilisateur MySQL
$password = ""; // Votre mot de passe MySQL
$database = "fabmanager"; // Votre base de données
$conn = new mysqli($servername, $username, $password, $database);

// Vérification de la connexion
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insérer des données dans la base de données lors de l'inscription
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['signup'])) {
    $new_username = $_POST['new_username'];
    $new_password = $_POST['new_password'];

    // Requête SQL pour insérer un nouvel utilisateur dans la base de données
    $insert_sql = "INSERT INTO utilisateur (username, password) VALUES ('$new_username', '$new_password')";

    if ($conn->query($insert_sql) === TRUE) {
        // Redirection vers la page de connexion après l'inscription réussie
        header("Location: page_crée.php");
        exit();
    } else {
        // Gestion des erreurs lors de l'inscription
        $error = "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fabmanager - Sign Up</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://chantiersdumaroc.ma/wp-content/uploads/2020/09/ECC-Casablanca-2-709x392.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            color: #fff;
        }
        .container {
            width: 300px;
            padding: 20px;
            background-color: rgba(0, 0, 0, 0.7);
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            text-align: center;
        }
        h1 {
            margin-bottom: 20px;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: none;
            border-radius: 5px;
            box-sizing: border-box;
            background-color: rgba(255, 255, 255, 0.3);
            color: #fff;
            outline: none;
        }
        input[type="text"]::placeholder, input[type="password"]::placeholder {
            color: #ddd;
        }
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .footer {
            margin-top: 20px;
            color: #ddd;
        }
        .error {
            color: red;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Créer un nouveau compte d'étudiant sur Fabmanager!</h1>
        <form action="" method="post">
            <input type="text" name="new_username" placeholder="Nouveau Utilisateur" required>
            <input type="password" name="new_password" placeholder="Nouveau mot de passe" required>
            <input type="submit" name="signup" value="Créer">
        </form>
        <div class="footer">
            Veuillez saisir les informations de créaction du compte
        </div>
        <?php if(isset($error)) { ?>
            <div class="error"><?php echo $error; ?></div>
        <?php } ?>
    </div>
</body>
</html>

<?php
// Fermer la connexion à la base de données
$conn->close();
?>