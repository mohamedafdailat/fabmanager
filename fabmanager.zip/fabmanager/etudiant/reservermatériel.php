<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réservation de Matériel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="Reservermatériel.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Lien vers Font Awesome -->
    <style>
        /* Styles généraux */
        header {
            background-color: #3ed8b4; /* Couleur de fond de l'en-tête */
            color: #fff; /* Couleur du texte de l'en-tête */
            padding: 20px;
            text-align: center;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            background-color: #3ed8b4;
            transition: background-color 0.3s ease;
        }

        nav ul li a:hover {
            background-color: #36bfb0;
        }

        main {
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: auto;
        }

        .materials {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .material {
            background-color: #fff; /* Couleur de fond des sections */
            padding: 20px;
            margin: 10px;
            border-radius: 10px; /* Coins arrondis pour les sections */
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Ombre légère */
            width: calc(25% - 20px); /* 4 cartes par ligne */
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            transition: transform 0.3s ease; /* Transition pour l'effet de soulèvement */
        }

        .material:hover {
            transform: translateY(-10px); /* Effet de soulèvement */
        }

        h2 {
            color: #3cd4d1; /* Couleur du titre de section */
            margin-bottom: 10px;
        }

        .material img {
            width: 100%;
            height: 210px;
            object-fit: cover;
            border-radius: 10px;
            margin-bottom: 15px;
            transition: transform 0.3s ease; /* Transition pour l'effet de zoom */
        }

        .material img:hover {
            transform: scale(1.1); /* Effet de zoom */
            transform: rotate(10deg); /* Effet de rotation */
        }

        .button-container {
            text-align: center;
            margin-top: 20px;
        }

        .button {
            padding: 10px 20px;
            background-color: #3ed8b4;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.3s;
        }

        .button:hover {
            background-color: #36bfb0;
            transform: translateY(-5px); /* Effet de soulèvement */
        }

        .not-available {
            color: red;
        }

        .not-accessible {
            color: blue;
        }

        .out-of-stock {
            filter: grayscale(100%);
        }

        .description {
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
            max-height: 3.6em;
            margin-bottom: 10px;
            position: relative;
            transition: max-height 0.3s ease; /* Transition pour l'effet de glissement */
        }

        .description.expanded {
            -webkit-line-clamp: unset;
            max-height: none;
        }

        .see-more {
            color: #3cd4d1;
            cursor: pointer;
        }

        form {
            width: 100%;
        }

        label, input[type="number"], input[type="submit"] {
            width: 100%;
            box-sizing: border-box;
            margin-top: 10px;
        }

        label {
            text-align: left;
            display: block;
            margin-bottom: 5px;
        }

        input[type="number"] {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        input[type="submit"] {
            padding: 10px 0;
            background-color: #3ed8b4;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #36bfb0;
        }
        header {
        display: flex;
        align-items: center; /* Alignement vertical au centre */
        background-color: #3ed8b4; /* Couleur de fond de l'en-tête */
        color: #fbfbfb; /* Couleur du texte de l'en-tête */
        padding: 20px;
        }

         #company-logo {
         height: 80px; /* Taille du logo */
         width: auto;
         margin-right: 10px; /* Espace à droite du logo */
        }

         h1 {
         margin: 20; /* Supprimer la marge pour éviter l'espace supplémentaire */
         font-size: 1.5em; /* Taille du titre augmentée */
        }

        nav {
            margin-left: auto; /* Aligner la nav à droite */
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fbfbfb;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            transition: color 0.3s ease;
        }

       nav ul li a:hover {
            background-color: #36bfb0;
        }
        .notification-icon:hover{
            background-color: #36bfb0;

        }  

    </style>
</head>
<body>
<header>
<img src="logo.png" alt="Logo de l'entreprise" id="company-logo">

    <h1>Tableau de bord - Étudiant</h1>
    <nav>
    <ul>
        <!-- <li><a href="">Accueil</a></li> -->
        <li><a href="reservermatériel.php"><i class="fa-solid fa-calendar-check"></i> Réserver le matériel</a></li>
        <!-- <li><a href="Reservation.php">Réserver un créneau </a></li> -->
        <li><a href="manipulation.php"><i class="fa-solid fa-microscope"></i> Consulter les manipulations</a></li>
        <li><a href="autre_page.php"><i class="fa-solid fa-info-circle"></i> À propos de nous</a></li>
        <li><a href="Mod.php"><i class="fa-solid fa-user"></i> Profile</a></li>
        <li><a href="login.php"><i class="fa-solid fa-sign-out-alt"></i> Déconnexion</a></li>
    </ul>
    </nav>
</header>
    <div class="container">
        <h1>Réservation de matériel </h1>
        <div class="materials">
            <?php
            // Connexion à la base de données
            $conn = new mysqli('localhost', 'root', '', 'fabmanager');

            // Vérifier la connexion
            if ($conn->connect_error) {
                die("La connexion a échoué: " . $conn->connect_error);
            }

            // Récupérer les matériaux depuis la base de données
            $sql = "SELECT * FROM matériels";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="material">';
                    // Vérifier la disponibilité du matériel
                    $imageClass = ($row['Disponibilité'] == 0 || $row['Quantité'] <= 0) ? 'out-of-stock' : '';
                    echo '<img src="' . $row['Image'] . '" alt="' . $row['NomMatériel'] . '" class="' . $imageClass . '">';
                    echo '<h2>' . $row['NomMatériel'] . '</h2>';
                    echo '<p class="description">' . $row['Description'] . '</p>';
                    echo '<span class="see-more">Voir plus</span>';
                    echo '<p>Quantité disponible : ' . $row['Quantité'] . '</p>';
                    // Afficher le bouton d'ajout au panier uniquement si le matériel est disponible
                    if ($row['Disponibilité'] > 0 && $row['Quantité'] > 0) {
                        echo '<form action="ReserverAction.php" method="post">';
                        echo '<input type="hidden" name="NomMatériel" value="' . $row['NomMatériel'] . '">';
                        echo '<label for="quantity">Quantité :</label>';
                        echo '<input type="number" id="quantity" name="quantity" min="1" max="' . $row['Quantité'] . '" required>';
                        echo '<input type="submit" value="Ajouter" name="submit">';
                        echo '</form>';
                    } elseif ($row['Quantité'] <= 0) {
                        echo '<p class="not-available">Ce matériel n\'est actuellement pas disponible en stock.</p>';
                    } else {
                        echo '<p class="not-accessible">Ce matériel n\'est actuellement pas disponible.</p>';
                    }

                    echo '</div>';
                }
            } else {
                echo "Aucun matériel disponible.";
            }

            // Fermer la connexion à la base de données
            $conn->close();
            ?>
        </div>
    </div>
    <script>
        document.querySelectorAll('.see-more').forEach(function(button) {
            button.addEventListener('click', function() {
                const description = this.previousElementSibling;
                description.classList.toggle('expanded');
                if (description.classList.contains('expanded')) {
                    this.textContent = 'Voir moins';
                } else {
                    this.textContent = 'Voir plus';
                }
            });
        });
    </script>
</body>
</html>
