<?php
session_start();

// Vérifie si le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connexion à la base de données
    $db_host = 'localhost';
    $db_name = 'fabmanager';
    $db_user = 'root';
    $db_pass = '';

    try {
        $conn = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Récupère les données du formulaire
        $NomResponsable = $_POST['NomResponsable'];
        $Typedereservation = $_POST['Typedereservation'];
        $DateReservation = $_POST['DateReservation'];
        $Heure = $_POST['Heure'];
        $UserID = $_POST['UserID'];

        // Vérification des données
        if (empty($NomResponsable) || empty($Typedereservation) || empty($DateReservation) || empty($Heure)) {
            throw new Exception("Tous les champs sont requis.");
        }

        // Vérification de la disponibilité du créneau
        $sql_check_availability = "SELECT COUNT(*) AS count FROM réservation WHERE DateReservation = :DateReservation AND Heure = :Heure";
        $stmt_check_availability = $conn->prepare($sql_check_availability);
        $stmt_check_availability->bindParam(':DateReservation', $DateReservation);
        $stmt_check_availability->bindParam(':Heure', $Heure);
        $stmt_check_availability->execute();
        $availability = $stmt_check_availability->fetch(PDO::FETCH_ASSOC);

        if ($availability['count'] > 0) {
            // Créneau déjà réservé, stocker les données dans la session et rediriger
            $_SESSION['form_data'] = [
                'NomResponsable' => $NomResponsable,
                'Typedereservation' => $Typedereservation,
                'DateReservation' => $DateReservation,
                'Heure' => $Heure
            ];
            echo "<script>alert('Ce créneau le $DateReservation à $Heure est déjà réservé.'); window.location.href='Reservation.php';</script>";
            exit;
        }

        // Mise à jour des quantités de matériel dans la base de données
        foreach ($_SESSION['panier'] as $reservation) {
            $materialName = $reservation['NomMatériel'];
            $quantity = $reservation['Quantité'];

            $sql_update_quantity = "UPDATE matériels SET Quantité = Quantité - :quantity WHERE NomMatériel = :materialName";
            $stmt_update_quantity = $conn->prepare($sql_update_quantity);
            $stmt_update_quantity->bindParam(':quantity', $quantity);
            $stmt_update_quantity->bindParam(':materialName', $materialName);
            $stmt_update_quantity->execute();

            // Vérifier si la quantité est inférieure ou égale à zéro
            $sql_check_quantity = "SELECT Quantité FROM matériels WHERE NomMatériel = :materialName";
            $stmt_check_quantity = $conn->prepare($sql_check_quantity);
            $stmt_check_quantity->bindParam(':materialName', $materialName);
            $stmt_check_quantity->execute();
            $result = $stmt_check_quantity->fetch(PDO::FETCH_ASSOC);

            if ($result['Quantité'] <= 0) {
                // Mettre à jour la disponibilité à zéro
                $sql_update_disponibility = "UPDATE matériels SET Disponibilité = 0 WHERE NomMatériel = :materialName";
                $stmt_update_disponibility = $conn->prepare($sql_update_disponibility);
                $stmt_update_disponibility->bindParam(':materialName', $materialName);
                $stmt_update_disponibility->execute();
            }
        }

        // Insertion des données de réservation dans la base de données
        $sql_insert_reservation = "INSERT INTO réservation (NomResponsable, Typedereservation, DateReservation, Heure, utilisateur_id) VALUES (:NomResponsable, :Typedereservation, :DateReservation, :Heure, :utilisateur_id)";
        $stmt_insert_reservation = $conn->prepare($sql_insert_reservation);
        $stmt_insert_reservation->bindParam(':NomResponsable', $NomResponsable);
        $stmt_insert_reservation->bindParam(':Typedereservation', $Typedereservation);
        $stmt_insert_reservation->bindParam(':DateReservation', $DateReservation);
        $stmt_insert_reservation->bindParam(':Heure', $Heure);
        $stmt_insert_reservation->bindParam(':utilisateur_id', $UserID);

        // Exécution de la requête
        $stmt_insert_reservation->execute();
        echo "<script>alert('Réservation effectuée avec succès !'); window.location.href='AnnulerReservation.php';</script>";

        // Supprimer les données de la session une fois qu'elles ont été traitées
        unset($_SESSION['panier']);
        unset($_SESSION['reservation']);
    } catch(PDOException $e) {
        echo "Erreur de connexion ou d'insertion : " . $e->getMessage();
    } catch(Exception $e) {
        echo "Erreur : " . $e->getMessage();
    }
} else {
    // Rediriger vers une autre page si les données de formulaire n'ont pas été soumises
    header('Location: index.php');
    exit;
}
?>
