<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fabmanager";

// Connexion à la base de données
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

// Récupérer les dates de réservation disponibles
$sql = "SELECT DISTINCT date FROM reservation_slots WHERE disponible = TRUE AND date NOT IN (SELECT date FROM reservations)";
$result = $conn->query($sql);

$dates = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $dates[] = $row['date'];
    }
}

$conn->close();

// Envoyer les dates au format JSON
header('Content-Type: application/json');
echo json_encode($dates);
?>
