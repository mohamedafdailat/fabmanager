<?php
// Connexion à la base de données
$db_host = 'localhost';
$db_name = 'fabmanager';
$db_user = 'root';
$db_pass = '';

$conn = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Récupérer les données du formulaire
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = $_POST['nom'];
    $disponibilite = $_POST['disponibilite'];
    $quantite = $_POST['quantite'];
    $emplacement = $_POST['emplacement'];
    $description = $_POST['description'];
    $ImageLink = $_POST['Image'];

    // Télécharger l'image à partir du lien
    $ImageData = file_get_contents($ImageLink);

    // Encoder les données de l'image en base64
    $encodedImageData = base64_encode($ImageData);

    // Préparer et exécuter la requête SQL
    $sql = "INSERT INTO matériels (NomMatériel, Disponibilité, Quantité, EmplacementFablab, Description, Image) VALUES (:nom, :disponibilite, :quantite, :emplacement, :description, :Image)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':nom', $nom);
    $stmt->bindParam(':disponibilite', $disponibilite);
    $stmt->bindParam(':quantite', $quantite);
    $stmt->bindParam(':emplacement', $emplacement);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':Image', $encodedImageData);

    try {
        $stmt->execute();
        echo "Matériel ajouté avec succès !";
    } catch(PDOException $e) {
        echo "Erreur d'insertion : " . $e->getMessage();
    }
}
?>



