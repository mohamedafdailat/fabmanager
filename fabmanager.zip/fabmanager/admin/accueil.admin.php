<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord - Administrateur</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Lien vers Font Awesome -->
    <style>
        /* Styles généraux */
        body {
            font-family: Arial, sans-serif;
            background-color: #f6f6f7;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #3ed8b4;
            color: #fff;
            padding: 20px;
            text-align: left;
            display: flex;
            align-items: center;
        }

        #company-logo {
            height: 70px;
            width: auto;
            margin-right: 20px;
        }

        h1 {
            margin: 0;
            font-size: 1.5em;
        }

        nav {
            margin-left: auto;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
        }

        nav ul li {
            margin-right: 20px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        nav ul li a:hover {
            background-color: #36bfb0;
        }

        main {
            padding: 20px;
            display: flex;
            justify-content: space-between;
        }

        section {
            background-color: #fff;
            padding: 20px;
            margin: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            width: calc(100% - 340px);
        }

        .sidebar {
            background-color: #3ed8b4;
            color: #fff;
            padding: 20px;
            margin: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        .sidebar h2 {
            margin-bottom: 20px;
            font-size: 1.5em;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar li {
            margin-bottom: 20px;
        }

        .sidebar li a {
            text-decoration: none;
            color: #fff;
            font-size: 1.2em;
            transition: color 0.3s ease;
        }

        .sidebar li a:hover {
            color: #36bfb0;
        }

        .button-container {
            text-align: center;
            margin-top: 20px;
        }

        .button {
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            font-size: 1em;
            margin-right: 10px;
        }

        .btn-confirm {
            background-color: #4CAF50;
            color: white;
            border: none;
        }

        .btn-confirm:hover {
            background-color: #45a049;
        }

        .btn-reject {
            background-color: #f44336;
            color: white;
            border: none;
        }

        .btn-reject:hover {
            background-color: #da190b;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }
    </style>
</head>
<body>
    <header>
        <img src="logo.png" alt="Logo de l'entreprise" id="company-logo">
        <h1>Tableau de bord - Administrateur</h1>
        <nav>
        <ul>
            <li><a href="https://centrale-casablanca.ma/vie-de-leleve/ressources-documentaires/ressources-numeriques/"><i class="fas fa-user"></i> Assistante</a></li>
            <li><a href="messagerie.php"><i class="fas fa-envelope"></i> Messagerie</a></li>
            <li><a href="login.admin.php"><i class="fas fa-times"></i> Déconnexion</a></li>
        </ul>
        </nav>
    </header>
    <main>
        <div class="sidebar">
            <h2>Actions Rapides</h2>
            <ul>
                <li><a href="/fabmanager/etudiant/signup.php"><i class="fas fa-user-plus"></i> Créer un compte Utilisateur</a></li>
                <br><br>
                <li><a href="gestionmatériels.php"><i class="fas fa-laptop"></i> Mettre à jour le matériel</a></li>
                <br><br>
                <li><a href="gestionmatériels.php"><i class="fas fa-clock"></i> Vérifier la disponibilité</a></li>
                <br><br>
                <li><a href="gestion_projet_liés.php"><i class="fas fa-link"></i> Projets Liés </a></li>
            </ul>
        </div>
        <section>
        <?php
        // Connexion à la base de données
        $conn = new mysqli('localhost', 'root', '', 'fabmanager');

        // Vérifier la connexion
        if ($conn->connect_error) {
            die("La connexion a échoué: " . $conn->connect_error);
        }

        // Vérifier quelle action a été effectuée par l'admin
        if (isset($_POST['action']) && isset($_POST['reservation_id'])) {
            $action = $_POST['action'];
            $reservation_id = $_POST['reservation_id'];

            // Mettre à jour le statut de la réservation et ajouter ou modifier le total des points
            if ($action == 'confirm') {
                // Mettre à jour le statut de la réservation
                $sql_update = "UPDATE réservation SET StatutReservation = 'Confirmé' WHERE ID = $reservation_id";
                $notification_message = "La réservation a été confirmée avec succès.";

                // Exécuter la mise à jour du statut de la réservation
                if ($conn->query($sql_update) === TRUE) {
                    // Récupérer l'utilisateur ID associé à la réservation
                    $sql_get_user_id = "SELECT utilisateur_id FROM réservation WHERE ID = $reservation_id";
                    $result_get_user_id = $conn->query($sql_get_user_id);

                    if ($result_get_user_id->num_rows > 0) {
                        $row = $result_get_user_id->fetch_assoc();
                        $utilisateur_id = $row['utilisateur_id'];

                        // Vérifier si l'utilisateur existe déjà dans la table classement
                        $check_user_sql = "SELECT * FROM classment WHERE utilisateur_id = $utilisateur_id";
                        $result_check_user = $conn->query($check_user_sql);

                        if ($result_check_user->num_rows > 0) {
                            $sql_update_points = "UPDATE classment SET point_total = point_total + 1 WHERE utilisateur_id = $utilisateur_id";
                        } else {
                            $sql_update_points = "INSERT INTO classment (utilisateur_id, reservation_id, point_total) VALUES ($utilisateur_id, $reservation_id, 1)";
                        }

                        // Exécuter la mise à jour ou l'insertion des points
                        if ($conn->query($sql_update_points) === TRUE) {
                            echo "<script>alert('$notification_message');</script>";
                        } else {
                            echo "Erreur lors de la mise à jour des points: " . $conn->error;
                        }
                    } else {
                        echo "Erreur: Aucun utilisateur trouvé pour cette réservation.";
                    }
                } else {
                    echo "Erreur lors de la mise à jour du statut de la réservation: " . $conn->error;
                }
            } elseif ($action == 'reject') {
                // Mettre à jour le statut de la réservation en "Refusé"
                $sql_update = "UPDATE réservation SET StatutReservation = 'Refusé' WHERE ID = $reservation_id";
                $notification_message = "La réservation a été refusée.";

                if ($conn->query($sql_update) === TRUE) {
                    echo "<script>alert('$notification_message');</script>";
                } else {
                    echo "Erreur lors de la mise à jour du statut de la réservation: " . $conn->error;
                }
            }
        }

        // Récupérer les réservations de matériel depuis la base de données
        $sql = "SELECT ID, NomResponsable, Typedereservation, DateReservation, Heure, StatutReservation FROM réservation";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<table>";
            echo "<tr><th>Nom du Responsable</th><th>Type de réservation</th><th>Date de réservation</th><th>Heure</th><th>Statut</th><th>Actions</th></tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['NomResponsable'] . "</td>";
                echo "<td>" . $row['Typedereservation'] . "</td>";
                echo "<td>" . $row['DateReservation'] . "</td>";
                echo "<td>" . $row['Heure'] . "</td>";
                echo "<td>" . $row['StatutReservation'] . "</td>";
                echo "<td>";
                echo "<form action='' method='POST'>";
                echo "<input type='hidden' name='reservation_id' value='" . $row['ID'] . "'>";
                echo "<button type='submit' name='action' value='confirm' class='button btn-confirm'>Confirmer</button>";
                echo "<button type='submit' name='action' value='reject' class='button btn-reject'>Rejeter</button>";
                echo "</form>";
                echo "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "Aucune réservation trouvée.";
        }

        $conn->close();
        ?>
        </section>
    </main>
</body>
</html>
