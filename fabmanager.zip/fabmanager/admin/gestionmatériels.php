<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord - Administrateur</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Lien vers Font Awesome -->
    <style>
        /* Styles généraux */
        body {
            font-family: Arial, sans-serif;
            background-color: #f6f6f7; /* Couleur de fond légère */
            color: #333; /* Couleur de texte principale */
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #3ed8b4; /* Couleur de fond de l'en-tête */
            color: #fff; /* Couleur du texte de l'en-tête */
            padding: 0px;
            text-align: center;
        }

        nav {
            background-color: #3ed8b4; /* Couleur de fond de la navigation */
            padding: 0px 0; /* Espace intérieur haut/bas pour les boutons */
            text-align: center;
        }

        nav a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            padding: 0px 0px;
            border-radius: 5px;
            margin-right: 60px;
            transition: background-color 0.3s ease;
        }

        nav a:hover {
            background-color: #36bfb0;
        }

        main {
            padding: 20px;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        section {
            background-color: #fff; /* Couleur de fond des sections */
            padding: 20px;
            margin: 20px;
            border-radius: 10px; /* Coins arrondis pour les sections */
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Ombre légère */
            width: 190px;
        }

        h2 {
            color: #3cd4d1; /* Couleur du titre de section */
            margin-bottom: 10px;
            text-align: center;
        }

        ul {
            list-style-type: none;
            padding: 10;
            text-align: left;
        }

        li {
            margin-bottom: 10px;
        }

        .button-container {
            text-align: center;
            margin-top: 70px;
        }

        .button {
            padding: 0px 20px;
            background-color: #3ed8b4;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .button:hover {
            background-color: #36bfb0;
        }
        .logo {
            width: 80px; /* Largeur de l'image en pixels */
            height: 80px; /* Hauteur de l'image en pixels */
        }
        .container {
    display: flex;
    flex-wrap: wrap;
}

         .box {
    flex: 1;
    padding: 20px;
    text-align: center;
    border: 1px solid #ccc;
    margin: 10px;
         }

         .box img {
    width: 100%; /* Pour occuper toute la largeur de la boîte */
    height: 200px; /* Hauteur fixe pour toutes les images */
    object-fit: cover; /* Redimensionne l'image tout en conservant son ratio d'aspect */
}


         .box button {
           margin-top: 10px;
           padding: 5px 10px;
           background-color: #007bff;
           color: #fff;
           border: none;
           border-radius: 5px;
           cursor: pointer;
           transition: background-color 0.3s;
         }

             .box button:hover {
             background-color: #0056b3;
             }

             
    </style>
</head>
<body>
    <header>
        <div class="header-content">
            <div class="platform-info">
                <div class="platform-name">
                    <img src="logo.png" alt="Logo" class="logo">
                </div>
            </div>
            <h1>Tableau de bord - Administrateur</h1>
        </div>
        <!-- Ajout de la navigation avec les boutons -->
        <nav>
    <a href="accueil.admin.php"><i class="fas fa-home"></i> Accueil</a>
    <a href="accueil.admin.php"><i class="fas fa-calendar-alt"></i> Gérer les réservations</a>
    <a href="gestionmatériels.php"><i class="fas fa-cogs"></i> Gérer le matériel</a>
    <a href="/fabmanager-main/index.php"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
    <br><br><br>
</nav>
    </nav>
    </header>
    <div class="container">
    <div class="box">
        <img src="https://mlodytechnik.pl/i/images/9/3/5/dz05MDAmaD02MDE=_src_13935-drukarka_3D.jpg" alt="Modifier la disponibilité ">
        <button onclick="window.location.href = 'modifierladiponibilité.php';">Modifier la disponibilité du matériel</button>
    </div>
    <div class="box">
        <img src="https://th.bing.com/th/id/OIP.lCP8adYlGoKJEo6EpbEmBgHaFj?rs=1&pid=ImgDetMain" alt="Ajouter un matériel">
        <button onclick="window.location.href = 'ajoutermatériel.php';">Ajouter un matériel </button>
    </div>
    <div class="box">
        <img src="https://th.bing.com/th/id/R.9691cfc33078cdf393ad7c4b5b7e6a07?rik=dJnkUK0ieQaA7w&pid=ImgRaw&r=0" alt="Modifier la quantité du matériel">
        <button onclick="window.location.href = 'modifierquantité.php';">Modifier la quantité du matériel</button>
    </div>
    <div class="box">
        <img src="https://th.bing.com/th/id/R.9691cfc33078cdf393ad7c4b5b7e6a07?rik=dJnkUK0ieQaA7w&pid=ImgRaw&r=0" alt="Modifier l'emplacement du matériel" >
        <button onclick="window.location.href = 'emplacementmatériels.php';">Modifier l'emplacement du matériel</button>
    </div>
      
</div>

</body>
