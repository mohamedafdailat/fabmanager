<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord - Administrateur</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Lien vers Font Awesome -->
    <style>
        /* Styles généraux */
        body {
            font-family: Arial, sans-serif;
            background-color: #f6f6f7; /* Couleur de fond légère */
            color: #333; /* Couleur de texte principale */
            margin: 0;
            padding: 0;
        }
        .header-content {
             display: flex;
            align-items: center;
        }

        .platform-name {
           display: flex;
           align-items: center;
        }

        .logo {
          height:  110px; /* Taille du logo */
          width: auto;
         margin-right: 10px; /* Espace à droite du logo */
        }


        header {
            background-color: #3ed8b4; /* Couleur de fond de l'en-tête */
            color: #fff; /* Couleur du texte de l'en-tête */
            padding: 0px;
            text-align: center;
        }

        nav {
            background-color: #3ed8b4; /* Couleur de fond de la navigation */
            padding: 0px 0; /* Espace intérieur haut/bas pour les boutons */
            text-align: center;
        }

        nav a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            padding: 0px 0px;
            border-radius: 5px;
            margin-right: 60px;
            transition: background-color 0.3s ease;
        }

        nav a:hover {
            background-color: #36bfb0;
        }

        main {
            padding: 20px;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        .form-box {
            background-color: #fff; /* Couleur de fond du box */
            padding: 20px;
            border-radius: 10px; /* Coins arrondis pour le box */
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Ombre légère */
            width: 400px; /* Largeur du box */
            margin: 20px auto; /* Centrer le box horizontalement */
        }

        .form-box h2 {
            color: #3cd4d1; /* Couleur du titre */
            margin-bottom: 20px;
            text-align: center;
        }

        .form-box label {
            display: block;
            margin-bottom: 5px;
        }

        .form-box input[type="text"],
        .form-box input[type="number"],
        .form-box textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        .form-box input[type="submit"] {
            background-color: #3ed8b4;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .form-box input[type="submit"]:hover {
            background-color: #36bfb0;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-content">
            <div class="platform-info">
                <div class="platform-name">
                <img src="logo.png" alt="Logo" class="logo">
                    <h1>FABMANAGER</h1>
                </div>
            </div>
            <br><br>
            <h1>: Tableau de bord - Administrateur</h1>
        </div>
        <!-- Ajout de la navigation avec les boutons -->
        <nav>
    <a href="accueil.admin.php"><i class="fas fa-home"></i> Accueil</a>
    <a href="accueil.admin.php"><i class="fas fa-calendar-alt"></i> Gérer les réservations</a>
    <a href="gestionmatériels.php"><i class="fas fa-cogs"></i> Gérer le matériel</a>
    <a href="/fabmanager-main/index.php"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
    <br><br><br>
</nav>
    </header>
    <div class="sidebar">
            <h2>Actualiser le matériel: </h2>
        </div>
    <main>
        <div class="form-box">
            <h2>Ajouter un matériel</h2>
            <form action="ajouter_materiel.php" method="post" enctype="multipart/form-data">
                <label for="nom">Nom du matériel :</label>
                <input type="text" id="nom" name="nom" required>
                <label for="disponibilite">Disponibilité :</label>
                <input type="number" id="disponibilite" name="disponibilite" min="0" required>
                <label for="quantite">Quantité :</label>
                <input type="number" id="quantite" name="quantite" min="0" required>
                <label for="emplacement">Emplacement dans le FabLab :</label>
                <input type="text" id="emplacement" name="emplacement" required>
                <label for="description">Description :</label>
                <textarea id="description" name="description" rows="4" cols="50" required></textarea>
                <label for="Image">Lien de l'image :</label>
                <input type="text" id="Image" name="Image" required>
                <input type="submit" value="Ajouter">
            </form>
        </div>
    </main>
</body>
</html>


     
 