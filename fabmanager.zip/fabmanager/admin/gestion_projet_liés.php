<?php
session_start();

// Connexion à la base de données
$servername = "localhost";
$username = "root"; // Votre nom d'utilisateur MySQL
$password = ""; // Votre mot de passe MySQL
$database = "fabmanager"; // Votre base de données
$conn = new mysqli($servername, $username, $password, $database);

// Vérification de la connexion
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Récupérer tous les projets avec les noms des étudiants
$sql = "SELECT p.id, p.idetudiant, p.nomprojet, u.username 
        FROM project_links p 
        JOIN utilisateur u ON p.idetudiant = u.id";
$result = $conn->query($sql);

// Tableau pour stocker les projets
$projects = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $projects[] = $row;
    }
} else {
    $error_message = "Aucun projet trouvé.";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Projets Liés</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f6f6f7;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #3ed8b4;
            color: #fff;
            padding: 20px;
            text-align: left;
            display: flex;
            align-items: center;
        }

        #company-logo {
            height: 70px;
            width: auto;
            margin-right: 20px;
        }

        h1 {
            margin: 0;
            font-size: 1.5em;
        }

        nav {
            margin-left: auto;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
        }

        nav ul li {
            margin-right: 20px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        nav ul li a:hover {
            background-color: #36bfb0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .container h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .error {
            color: red;
            text-align: center;
        }
    </style>
</head>
<body>
    <header>
        <img src="logo.png" alt="Logo de l'entreprise" id="company-logo">
        <h1>Tableau de bord - Administrateur</h1>
        <nav>
            <ul>
                <li><a href="https://centrale-casablanca.ma/vie-de-leleve/ressources-documentaires/ressources-numeriques/"><i class="fas fa-user"></i> Assistante</a></li>
                <li><a href="messagerie.php"><i class="fas fa-envelope"></i> Messagerie</a></li>
                <li><a href="login.admin.php"><i class="fas fa-times"></i> Déconnexion</a></li>
            </ul>
        </nav>
    </header>
    <div class="container">
        <h1>Liste des Projets Liés</h1>
        <?php if (isset($error_message)) { ?>
            <div class="error"><?php echo $error_message; ?></div>
        <?php } else { ?>
            <table>
                <thead>
                    <tr>
                        <th>ID Projet</th>
                        <th>ID Étudiant</th>
                        <th>Nom de l'Étudiant</th>
                        <th>Nom du Projet</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($projects as $project) { ?>
                        <tr>
                            <td><?php echo $project['id']; ?></td>
                            <td><?php echo $project['idetudiant']; ?></td>
                            <td><?php echo $project['username']; ?></td>
                            <td><?php echo $project['nomprojet']; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        <?php } ?>
    </div>
</body>
</html>
