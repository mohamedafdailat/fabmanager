<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messagerie - Administrateur</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Lien vers Font Awesome -->
    <style>
        /* Styles généraux */
        body {
            font-family: Arial, sans-serif;
            background-color: #f6f6f7; /* Couleur de fond légère */
            color: #333; /* Couleur de texte principale */
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #3ed8b4; /* Couleur de fond de l'en-tête */
            color: #fff; /* Couleur du texte de l'en-tête */
            padding: 20px;
            text-align: left;
            position: relative;
            display: flex;
            align-items: center;
        }

        #company-logo {
            height: 70px; /* Taille du logo agrandie */
            width: auto;
            margin-right: 20px; /* Espace à droite du logo */
        }

        h1 {
            margin: 0; /* Supprimer les marges autour du titre */
            font-size: 1.5em; /* Taille du titre augmentée */
        }

        nav {
            margin-left: auto; /* Aligner la nav à droite */
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            background-color: #3ed8b4;
            transition: background-color 0.3s ease;
        }

        nav ul li a:hover {
            background-color: #36bfb0;
        }

        main {
            padding: 20px;
            display: flex;
            justify-content: space-between;
        }

        section {
            background-color: #fff; /* Couleur de fond des sections */
            padding: 20px;
            margin: 20px;
            border-radius: 10px; /* Coins arrondis pour les sections */
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Ombre légère */
            width: calc(100% - 400px); /* Ajuster la largeur du contenu */
        }

        .sidebar {
            background-color: #3ed8b4; /* Couleur de fond de la sidebar */
            color: #fff; /* Couleur du texte de la sidebar */
            padding: 20px;
            margin: 20px;
            border-radius: 10px; /* Coins arrondis pour la sidebar */
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Ombre légère */
            width: 300px; /* Largeur fixe de la sidebar */
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .sidebar h2 {
            margin-bottom: 20px;
            font-size: 1.5em;
            color: #fff;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
            text-align: center;
        }

        .sidebar li {
            margin-bottom: 10px;
        }

        .sidebar li a {
            text-decoration: none;
            color: #fff;
            font-size: 1.2em;
            transition: color 0.3s ease;
        }

        .sidebar li a:hover {
            color: #36bfb0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <header>
        <img src="logo.png" alt="Logo de l'entreprise" id="company-logo">
        <h1>Messagerie - Administrateur</h1>
        <nav>
            <ul>
                <li><a href="accueil.admin.php">Accueil</a></li>
                <li><a href="#">Assistante</a></li>
                <!-- <li><a href="#">Messagerie</a></li> -->
                <li><a href="/fabmanager-main/index.php">Déconnexion</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <div class="sidebar">
            <h2>Actions Rapides</h2>
            <ul>
                <li><a href="/fabmanager/etudiant/signup.php"><i class="fas fa-user-plus"></i> Créer un compte Utilisateur</a></li>
                <br><br>
                <li><a href="gestionmatériels.php"><i class="fas fa-laptop"></i> Mettre à jour le matériel</a></li>
                <br><br>
                <li><a href="gestionmatériels.php"><i class="fas fa-clock"></i> Vérifier la disponibilité</a></li>
                <br><br>
                <li><a href="gestion_projet_liés.php"><i class="fas fa-link"></i> Projets Liés </a></li>
            </ul>
        </div>
        <section>
            <h2>Boîte de réception</h2>
            <table>
                <tr>
                    <th>Nom de l'expéditeur</th>
                    <th>Message</th>
                    <th>Actions</th>
                </tr>
                <?php
                // Connexion à la base de données
                $conn = new mysqli('localhost', 'root', '', 'fabmanager');

                // Vérifier la connexion
                if ($conn->connect_error) {
                    die("La connexion a échoué: " . $conn->connect_error);
                }

                // Récupérer les messages de la base de données
                $sql = "SELECT * FROM messagerie";
                $result = $conn->query($sql);

                // Vérifier s'il y a des messages à afficher
                if ($result->num_rows > 0) {
                    // Afficher les messages dans un tableau HTML
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['Nom'] . "</td>";
                        echo "<td>" . $row['Message'] . "</td>";
                        echo "<td>";
                        echo "<button class='button btn-reply'>Répondre</button>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='3'>Aucun message trouvé.</td></tr>";
                }

                // Fermer la connexion à la base de données
                $conn->close();
                ?>
            </table>
        </section>
    </main>
</body>
</html>
