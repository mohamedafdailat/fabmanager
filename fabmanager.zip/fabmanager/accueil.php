<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FabLab - Bienvenue</title>
    <!-- Inclure Font Awesome pour les icônes -->
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> -->
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            height: 100vh;
            background-image: url('https://chantiersdumaroc.ma/wp-content/uploads/2020/09/ECC-Casablanca-2-709x392.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            color: #fff; /* Texte blanc pour le contenu principal */
        }
        .container {
            width: 350px;
            padding: 20px;
            background-color: rgba(0, 0, 0, 0.5); /* Fond semi-transparent noir */
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            text-align: center;
            margin-bottom: 20px; /* Espace entre container et footer */
        }
        h1 {
            font-size: 28px;
            margin-bottom: 20px;
        }
        p {
            font-size: 18px;
            margin-bottom: 20px;
        }
        a {
            color: #007bff;
            text-decoration: none;
            font-size: 20px;
            margin: 10px;
            padding: 10px 20px;
            border: 2px solid #007bff;
            border-radius: 5px;
            transition: all 0.3s;
        }
        a:hover {
            background-color: #007bff;
            color: #fff;
        }
        .icon {
            font-size: 48px;
            margin-bottom: 20px;
        }
        .footer {
            text-align: center;
            padding: 20px;
            width: 100%;
            font-size: 18px; /* Taille plus grande pour le texte du footer */
            color: #000; /* Texte en noir pour le footer */
            background-color: rgba(249, 249, 249, 0.6); /* Fond encore plus transparent */
            border-radius: 8px; /* Ajout de bord arrondi */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); /* Ajout d'une ombre */
        }
    </style>
</head>
<body>
    <div class="container">
        <i class="fas fa-wrench icon"></i>
        <h1>Bienvenue au FabLab de l'École Centrale Casablanca!</h1>
        <p>Rejoignez-nous pour réserver des équipements et réaliser vos projets innovants.</p>
        <a href="etudiant/login.php">Connexion Étudiant</a>
        <br><br><br>
        <a href="admin/login.admin.php">Connexion Admin</a> <!-- Nouveau lien vers la page d'administration -->
    </div>
</body>
</html>