<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Nos Fonctionnalités:</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Lien vers Font Awesome -->
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f6f6f7; /* Couleur de fond légère */
      color: #2ec086; /* Couleur de texte principale */
    }
    /* Nouveau style pour positionner le logo à gauche */
    header {
        display: flex;
        align-items: center; /* Alignement vertical au centre */
        background-color: #3ed8b4; /* Couleur de fond de l'en-tête */
        color: #fbfbfb; /* Couleur du texte de l'en-tête */
        padding: 20px;
    }

    #company-logo {
        height: 80px; /* Taille du logo */
        width: auto;
        margin-right: 10px; /* Espace à droite du logo */
    }

    h1 {
        margin: 20; /* Supprimer la marge pour éviter l'espace supplémentaire */
    }


    section {
      background-color: #fff; /* Couleur de fond des sections */
      padding: 20px;
      margin-bottom: 20px;
      border-radius: 10px; /* Coins arrondis pour les sections */
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Ombre légère */
    }

    h2 {
      color: #3cd4d1; /* Couleur du titre de section */
      margin-bottom: 10px;
    }

    ul {
      list-style-type: none;
      padding: 0;
    }

    li {
      margin-bottom: 10px;
    }

    a {
      text-decoration: none;
      color: #333;
    }

    a:hover {
      color: #fbfbfb; /* Couleur du texte du lien au survol */
    }

    i {
      margin-right: 5px; /* Marge à droite des icônes */
    }
  </style>
</head>
<body>
    <header>
        <img src="etudiant/logo.png" alt="Logo de l'entreprise" id="company-logo">
        <h1>Nos Fonctionnalités sur FABMANAGER:</h1>
    </header>


  <main>
    <section>
      <h2>Fonctionnalité 1: Réservation fluide</h2>
      <p>Réservez facilement du matériel et des créneaux horaires avec notre système de réservation intuitif. Gagnez du temps et de l'efficacité dans la gestion de vos projets en planifiant vos besoins en quelques clics.</p>
    </section>

    <section>
      <h2>Fonctionnalité 2: Manipulation de matériel ou projets</h2>
      <p>Accédez à une large gamme d'outils et d'équipements avancés pour concrétiser vos idées et projets. Notre plateforme vous offre la possibilité de manipuler du matériel de pointe et de réaliser des projets innovants dans un environnement propice à la créativité.</p>
    </section>

    <section>
      <h2>Fonctionnalité 3: Recherche de matériel dans le Fablab</h2>
      <p>Identifiez rapidement et efficacement le matériel dont vous avez besoin grâce à notre système de recherche intégré. Trouvez facilement les outils et équipements nécessaires à la réalisation de vos projets en quelques clics, vous permettant ainsi de gagner du temps et de maximiser votre productivité.</p>
    </section>
  </main>

  <footer>
    <div class="fablab-info">
      <h3>À propos du FabLab</h3>
      <p>Le FabLab est un laboratoire de fabrication numérique ouvert à tous, où vous pouvez transformer vos idées en réalité. Doté d'équipements de pointe tels que des imprimantes 3D, des découpeuses laser et des machines CNC, le FabLab offre un environnement propice à l'innovation et à l'apprentissage collaboratif.</p>
      <p>Que vous soyez un professionnel, un étudiant ou un amateur passionné, le FabLab vous offre la possibilité d'explorer de nouvelles technologies, de prototyper des projets et de développer vos compétences en fabrication numérique.</p>
    </div>
    <div class="contact-info">
      <h3>Comment nous contacter</h3>
      <p>Pour plus d'informations sur nos services, nos formations ou nos événements à venir, n'hésitez pas à nous contacter :</p>
      <ul>
        <li>Téléphone : +212 6 46 56 97 88</li>
        <li>Email : contact@fablab.com</li>
        <li>Adresse : Ecole centrale casablanca, BOUSKOURA, MAROC</li>
      </ul>
    </div>
  </footer>
</body>
</html>
